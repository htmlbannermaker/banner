(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"181208_5xlp_300x600_atlas_P_", frames: [[610,821,55,46],[871,860,32,45],[610,869,31,43],[827,860,42,39],[704,869,31,34],[783,756,66,97],[746,821,27,23],[851,756,47,46],[787,855,38,46],[704,821,40,46],[746,855,39,46],[827,901,36,22],[643,876,42,24],[667,821,35,53],[851,804,36,54],[302,0,300,250],[604,0,300,250],[912,932,20,29],[643,902,33,18],[678,902,21,23],[302,252,300,250],[0,252,300,250],[604,252,300,250],[0,0,300,250],[0,504,300,250],[302,504,300,250],[610,932,300,48],[210,756,170,198],[604,504,300,250],[610,756,171,63],[906,0,112,231],[906,466,112,231],[496,756,112,231],[906,233,112,231],[382,756,112,231],[906,699,112,231],[0,756,208,220]]},
		{name:"181208_5xlp_300x600_atlas_NP_", frames: [[0,0,750,250]]}
];


// symbols:



(lib.Растровоеизображение1 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение10 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение11 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение13 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение14 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение15 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение16 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение2 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение3 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение4 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение5 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение6 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение7 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение8 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Растровоеизображение9 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.bg = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bottom_line = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.cta = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.l1 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.l2 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.l4 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.label = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.legal = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.p1 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.p2 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.p3 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.rain = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.sh = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.sunlight = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.txt2 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.w_arm11 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.w_arm12 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.w_arm21 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.w_arm22 = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.w_body = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.w_head = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.z2_arm = function() {
	this.initialize(ss["181208_5xlp_300x600_atlas_P_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#003461").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Symbol75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#003461").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.Symbol74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-50.1,0,50).s().p("A3bH0IAAvoMAu2AAAIAAPog");
	this.shape.setTransform(149.95,50.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,299.9,100.1);


(lib.Symbol72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg();
	this.instance.parent = this;

	this.shape = new cjs.Shape();
	var sprImg_shape = cjs.SpriteSheetUtils.extractFrame(ss["181208_5xlp_300x600_atlas_NP_"],0);
	sprImg_shape.onload = function(){
		this.shape.graphics.bf(sprImg_shape, null, new cjs.Matrix2D(1,0,0,-1.588,-375,371.7)).s().p("Eg6lAD8IAAn3MB1LAAAIAAH3g")
	}.bind(this);
	this.shape.setTransform(375,274.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,750,299.4);


(lib.Symbol65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение5();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol65, new cjs.Rectangle(0,0,39,46), null);


(lib.Symbol64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol64, new cjs.Rectangle(0,0,47,46), null);


(lib.Symbol63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol63, new cjs.Rectangle(0,0,38,46), null);


(lib.Symbol62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol62, new cjs.Rectangle(0,0,55,46), null);


(lib.Symbol61 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение4();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol61, new cjs.Rectangle(0,0,40,46), null);


(lib.Symbol60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.sunlight();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol60, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.rain();
	this.instance.parent = this;
	this.instance.setTransform(290.6,240,1,1.042,0,16.3265,180);

	this.instance_1 = new lib.rain();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-17,192);

	this.instance_2 = new lib.rain();
	this.instance_2.parent = this;
	this.instance_2.setTransform(317.05,144,1,1.042,0,16.3265,180);

	this.instance_3 = new lib.rain();
	this.instance_3.parent = this;
	this.instance_3.setTransform(11,96);

	this.instance_4 = new lib.rain();
	this.instance_4.parent = this;
	this.instance_4.setTransform(296.8,48,1,1.042,0,16.3265,180);

	this.instance_5 = new lib.rain();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol57, new cjs.Rectangle(-23.4,0,340.5,288), null);


(lib.Symbol54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.l4();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol54, new cjs.Rectangle(0,0,21,23), null);


(lib.Symbol52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.l2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol52, new cjs.Rectangle(0,0,33,18), null);


(lib.Symbol51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.l1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol51, new cjs.Rectangle(0,0,20,29), null);


(lib.Symbol50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol50, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	var sprImg_shape = cjs.SpriteSheetUtils.extractFrame(ss["181208_5xlp_300x600_atlas_NP_"],0);
	sprImg_shape.onload = function(){
		this.shape.graphics.bf(sprImg_shape, null, new cjs.Matrix2D(1,0,0,-1.819,-375,425.6)).s().p("Eg6lAEiIAApDMB1LAAAIAAJDg")
	}.bind(this);
	this.shape.setTransform(75,279.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.bg();
	this.instance.parent = this;
	this.instance.setTransform(-300,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol49, new cjs.Rectangle(-300,0,750,308.1), null);


(lib.Symbol48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_body();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol48, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_arm22();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol47, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_arm21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol46, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение13();
	this.instance.parent = this;
	this.instance.setTransform(7,30);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol45, new cjs.Rectangle(7,30,42,39), null);


(lib.Symbol44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_arm12();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol44, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_arm11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol43, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение16();
	this.instance.parent = this;
	this.instance.setTransform(51,31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol42, new cjs.Rectangle(51,31,27,23), null);


(lib.Symbol41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Растровоеизображение14();
	this.instance.parent = this;
	this.instance.setTransform(65,33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol41, new cjs.Rectangle(65,33,31,34), null);


(lib.Symbol40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.w_head();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol40, new cjs.Rectangle(0,0,112,231), null);


(lib.Symbol35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,231,169,0)","#FFE7A9","rgba(255,231,169,0)"],[0,0.498,1],-21.3,0,21.4,0).s().dr(-21.4,-30.4,42.8,60.8);
	this.shape.setTransform(34.5245,37.1149,1,1,33.2289);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35, new cjs.Rectangle(0,0,69.1,74.2), null);


(lib.Symbol32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol32, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.legal();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.label();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cta();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#4C8EBF","#4A8BBC","#3C7BAB","#0D4370","#053966","#003461"],[0,0.208,0.443,0.855,0.925,1],0,18.1,0,0,18.1,105.3).s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.txt2();
	this.instance.parent = this;
	this.instance.setTransform(67,16);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(67,16,171,63), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol46_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.z2_arm();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol46_1, new cjs.Rectangle(0,0,208,220), null);


(lib.Символ18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(-26,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ18, new cjs.Rectangle(-26,0,300,250), null);


(lib.Символ17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.bottom_line();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ17, new cjs.Rectangle(0,0,300,250), null);


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#C06C00","#EACA40","#D28D17"],[0,0.553,1],-56.3,0,56.4,0).s().p("AnNkIIAFgEIhritQDmiTFNgcQFOAcDlCTIhqCtIAFAEQBRK7ofC2Qoei2BRq7g");
	this.shape.setTransform(56.35,61.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15, new cjs.Rectangle(0,0,112.7,123.4), null);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.instance = new lib.sh();
	this.instance.parent = this;
	this.instance.setTransform(4.85,14.25,0.5955,0.5955,-5.7416);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ14, new cjs.Rectangle(4.9,4.1,112.5,127.5), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение6();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13, new cjs.Rectangle(0,0,36,22), null);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение7();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ12, new cjs.Rectangle(0,0,42,24), null);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение8();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ11, new cjs.Rectangle(0,0,35,53), null);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение9();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ10, new cjs.Rectangle(0,0,36,54), null);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение10();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ9, new cjs.Rectangle(0,0,32,45), null);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ8, new cjs.Rectangle(0,0,31,43), null);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Растровоеизображение15();
	this.instance.parent = this;
	this.instance.setTransform(22,34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1, new cjs.Rectangle(22,34,66,97), null);


(lib.Symbol71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// m (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_49 = new cjs.Graphics().p("AqghvQgvAAAAgvIAAjOQAAgvAvAAIVBAAQAvAAAAAvIAADOQAAAvgvAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(49).to({graphics:mask_graphics_49,x:66.1,y:-41.2}).wait(57));

	// light
	this.instance = new lib.Symbol35();
	this.instance.parent = this;
	this.instance.setTransform(-45.75,-67.05,1.2069,1.1873,0,0,0,34.6,37.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({x:179.85},12).wait(1).to({x:-45.75},0).to({x:179.85},12).wait(32));

	// cta.png
	this.instance_1 = new lib.Symbol13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(64.7,-17.5,1,1,0,0,0,214.7,223);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30).to({_off:false},0).to({y:-67.5,alpha:1},12,cjs.Ease.backOut).wait(64));

	// t11.png
	this.instance_2 = new lib.Symbol4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(100,-175,1,1,0,0,0,150,125);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).to({x:0,alpha:1},16,cjs.Ease.backOut).wait(86));

	// m (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_25 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_26 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_27 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_28 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_29 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_30 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_31 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_32 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_33 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_34 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_35 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_37 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_38 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_39 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_40 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_1_graphics_41 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(25).to({graphics:mask_1_graphics_25,x:-65.975,y:-188.025}).wait(1).to({graphics:mask_1_graphics_26,x:-51.025,y:-188.025}).wait(1).to({graphics:mask_1_graphics_27,x:-37.925,y:-188.025}).wait(1).to({graphics:mask_1_graphics_28,x:-26.575,y:-188.025}).wait(1).to({graphics:mask_1_graphics_29,x:-16.825,y:-188.025}).wait(1).to({graphics:mask_1_graphics_30,x:-8.575,y:-188.025}).wait(1).to({graphics:mask_1_graphics_31,x:-1.725,y:-188.025}).wait(1).to({graphics:mask_1_graphics_32,x:3.875,y:-188.025}).wait(1).to({graphics:mask_1_graphics_33,x:8.425,y:-188.025}).wait(1).to({graphics:mask_1_graphics_34,x:11.925,y:-188.025}).wait(1).to({graphics:mask_1_graphics_35,x:14.525,y:-188.025}).wait(1).to({graphics:mask_1_graphics_36,x:16.425,y:-188.025}).wait(1).to({graphics:mask_1_graphics_37,x:17.675,y:-188.025}).wait(1).to({graphics:mask_1_graphics_38,x:18.475,y:-188.025}).wait(1).to({graphics:mask_1_graphics_39,x:18.875,y:-188.025}).wait(1).to({graphics:mask_1_graphics_40,x:19.025,y:-188.025}).wait(1).to({graphics:mask_1_graphics_41,x:19.025,y:-188.025}).wait(65));

	// label.png
	this.instance_3 = new lib.Symbol15();
	this.instance_3.parent = this;
	this.instance_3.setTransform(71.6,-184.7,1,1,0,0,0,171.6,115.3);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(25).to({_off:false},0).to({x:21.6},16,cjs.Ease.cubicOut).wait(65));

	// p2.png
	this.instance_4 = new lib.Symbol1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0.5,-127.15,0.1207,0.1207,0,0,0,150.3,157.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).to({regX:150.5,scaleX:1,scaleY:1,y:-142.2,alpha:1},16,cjs.Ease.backOut).wait(89));

	// m (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AoTIiIAAxDIQnAAIAARDg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:51.475,y:-143.875}).wait(6).to({graphics:null,x:0,y:0}).wait(100));

	// p3.png
	this.instance_5 = new lib.Symbol2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-60,-175,1,1,0,0,0,150,125);
	this.instance_5.alpha = 0;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({x:0,alpha:1},16,cjs.Ease.quartOut).wait(86));

	// m (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_2 = new cjs.Graphics().p("Ar1NYIAA6vIXrAAIAAavg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_3_graphics_2,x:-71.75,y:-145.325}).wait(7).to({graphics:null,x:0,y:0}).wait(97));

	// p1.png
	this.instance_6 = new lib.Symbol32();
	this.instance_6.parent = this;
	this.instance_6.setTransform(55,-175,1,1,0,0,0,150,125);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(2).to({_off:false},0).wait(4).to({x:0,alpha:1},16,cjs.Ease.quartOut).wait(84));

	// legal.png
	this.instance_7 = new lib.Symbol31();
	this.instance_7.parent = this;
	this.instance_7.setTransform(0,-175,1,1,0,0,0,150,125);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(23).to({_off:false},0).to({alpha:1},16).wait(67));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-185.1,-315.2,373.1,324.7);


(lib.Symbol70 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// l1.png
	this.instance = new lib.Symbol51();
	this.instance.parent = this;
	this.instance.setTransform(282.9,-41.3,1,1,0,0,0,10,14.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).wait(1).to({rotation:11.2157,x:277.05,y:-32.55},0).wait(1).to({rotation:22.3346,x:271.2,y:-23.9},0).wait(1).to({rotation:33.3551,x:265.5,y:-15.3},0).wait(1).to({rotation:44.2754,x:259.75,y:-6.75},0).wait(1).to({rotation:55.0937,x:254.05,y:1.65},0).wait(1).to({rotation:65.8082,x:248.5,y:9.95},0).wait(1).to({rotation:76.4171,x:242.95,y:18.15},0).wait(1).to({rotation:86.9184,x:237.5,y:26.4},0).wait(1).to({rotation:97.3104,x:232.05,y:34.45},0).wait(1).to({rotation:107.5909,x:226.75,y:42.45},0).wait(1).to({rotation:117.7581,x:221.35,y:50.4},0).wait(1).to({rotation:127.81,x:216.1,y:58.2},0).wait(1).to({rotation:137.7446,x:210.95,y:65.9},0).wait(1).to({rotation:147.5598,x:205.8,y:73.55},0).wait(1).to({rotation:157.2535,x:200.8,y:81.15},0).wait(1).to({rotation:166.8237,x:195.75,y:88.6},0).wait(1).to({rotation:176.2683,x:190.8,y:95.95},0).wait(1).to({rotation:185.5852,x:185.95,y:103.2},0).wait(1).to({rotation:194.7722,x:181.2,y:110.35},0).wait(1).to({rotation:203.8274,x:176.4,y:117.4},0).wait(1).to({rotation:212.7485,x:171.8,y:124.35},0).wait(1).to({rotation:221.5335,x:167.15,y:131.15},0).wait(1).to({rotation:230.1804,x:162.7,y:137.9},0).wait(1).to({rotation:238.687,x:158.25,y:144.5},0).wait(1).to({rotation:247.0513,x:153.85,y:151.05},0).wait(1).to({rotation:255.2715,x:149.55,y:157.45},0).wait(1).to({rotation:263.3456,x:145.35,y:163.7},0).wait(1).to({rotation:271.2717,x:141.2,y:169.9},0).wait(1).to({rotation:279.0481,x:137.1,y:175.95},0).wait(1).to({rotation:286.6732,x:133.15,y:181.85},0).wait(1).to({rotation:294.1453,x:129.3,y:187.7},0).wait(1).to({rotation:301.4631,x:125.4,y:193.4},0).wait(1).to({rotation:308.6254,x:121.75,y:199},0).wait(1).to({rotation:315.6309,x:118.05,y:204.45},0).wait(1).to({rotation:322.4789,x:114.5,y:209.75},0).wait(1).to({rotation:329.1686,x:111,y:214.95},0).wait(1).to({rotation:335.6996,x:107.55,y:220.1},0).wait(1).to({rotation:342.0717,x:104.2,y:225},0).wait(1).to({rotation:348.285,x:101,y:229.85},0).wait(1).to({rotation:354.3401,x:97.85,y:234.6},0).wait(1).to({rotation:360.2378,x:94.75,y:239.2},0).wait(1).to({rotation:365.9792,x:91.75,y:243.65},0).wait(1).to({rotation:371.5661,x:88.85,y:248},0).wait(1).to({rotation:377.0006,x:86,y:252.2},0).wait(1).to({rotation:382.2853,x:83.25,y:256.35},0).wait(1).to({rotation:387.4233,x:80.55,y:260.35},0).wait(1).to({rotation:392.4185,x:78,y:264.25},0).wait(1).to({rotation:397.2752,x:75.4,y:268.05},0).wait(1).to({rotation:401.9984,x:72.95,y:271.75},0).wait(1).to({rotation:406.5936,x:70.5,y:275.25},0).wait(1).to({rotation:411.0673,x:68.2,y:278.8},0).wait(1).to({rotation:415.4264,x:65.9,y:282.2},0).wait(1).to({rotation:419.6787,x:63.75,y:285.45},0).wait(1).to({rotation:423.8326,x:61.55,y:288.75},0).wait(1).to({rotation:427.8974,x:59.4,y:291.85},0).wait(1).to({rotation:431.8828,x:57.3,y:294.95},0).wait(1).to({rotation:435.7995,x:55.3,y:298},0).wait(1).to({rotation:439.6585,x:53.3,y:301.05},0).wait(1).to({rotation:443.4718,x:51.3,y:304},0).wait(1).to({rotation:447.2515,x:49.3,y:306.95},0).wait(1).to({rotation:451.0107,x:47.3,y:309.9},0).wait(1).to({regX:10.1,rotation:454.7624,x:45.35,y:312.85},0).wait(159));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-55.8,292.9,379.8);


(lib.Symbol69 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// l2.png copy
	this.instance = new lib.Symbol52();
	this.instance.parent = this;
	this.instance.setTransform(148.05,-21,1,1,0,0,0,16.5,9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({rotation:-11.5804,x:143.55,y:-12.6},0).wait(1).to({rotation:-23.0593,x:139.2,y:-4.2},0).wait(1).to({rotation:-34.4348,x:134.75,y:3.9},0).wait(1).to({rotation:-45.7051,x:130.4,y:12.15},0).wait(1).to({rotation:-56.8682,x:126.15,y:20.2},0).wait(1).to({rotation:-67.9222,x:121.9,y:28.25},0).wait(1).to({rotation:-78.8651,x:117.7,y:36.15},0).wait(1).to({rotation:-89.695,x:113.5,y:44},0).wait(1).to({rotation:-100.4098,x:109.35,y:51.75},0).wait(1).to({rotation:-111.0073,x:105.3,y:59.45},0).wait(1).to({rotation:-121.4856,x:101.25,y:67.1},0).wait(1).to({rotation:-131.8425,x:97.3,y:74.55},0).wait(1).to({rotation:-142.0758,x:93.4,y:82},0).wait(1).to({rotation:-152.1833,x:89.45,y:89.35},0).wait(1).to({rotation:-162.1629,x:85.6,y:96.6},0).wait(1).to({rotation:-172.0123,x:81.8,y:103.7},0).wait(1).to({rotation:-181.7293,x:78.1,y:110.75},0).wait(1).to({rotation:-191.3116,x:74.4,y:117.7},0).wait(1).to({rotation:-200.757,x:70.75,y:124.55},0).wait(1).to({rotation:-210.0633,x:67.15,y:131.25},0).wait(1).to({rotation:-219.2283,x:63.6,y:137.95},0).wait(1).to({rotation:-228.2496,x:60.2,y:144.45},0).wait(1).to({rotation:-237.1251,x:56.8,y:150.9},0).wait(1).to({rotation:-245.8527,x:53.4,y:157.2},0).wait(1).to({rotation:-254.4301,x:50.1,y:163.5},0).wait(1).to({rotation:-262.8554,x:46.85,y:169.55},0).wait(1).to({rotation:-271.1265,x:43.65,y:175.6},0).wait(1).to({rotation:-279.2415,x:40.55,y:181.45},0).wait(1).to({rotation:-287.1986,x:37.5,y:187.2},0).wait(1).to({rotation:-294.996,x:34.45,y:192.85},0).wait(1).to({rotation:-302.6322,x:31.55,y:198.4},0).wait(1).to({rotation:-310.1058,x:28.7,y:203.8},0).wait(1).to({rotation:-317.4154,x:25.85,y:209.15},0).wait(1).to({rotation:-324.56,x:23.15,y:214.3},0).wait(1).to({rotation:-331.5388,x:20.4,y:219.35},0).wait(1).to({rotation:-338.3512,x:17.85,y:224.3},0).wait(1).to({rotation:-344.997,x:15.25,y:229.1},0).wait(1).to({rotation:-351.476,x:12.75,y:233.85},0).wait(1).to({rotation:-357.7886,x:10.4,y:238.4},0).wait(1).to({rotation:-363.9357,x:7.95,y:242.85},0).wait(1).to({rotation:-369.9183,x:5.7,y:247.15},0).wait(1).to({rotation:-375.7381,x:3.5,y:251.4},0).wait(1).to({rotation:-381.3972,x:1.3,y:255.55},0).wait(1).to({rotation:-386.8982,x:-0.85,y:259.55},0).wait(1).to({rotation:-392.2444,x:-2.9,y:263.4},0).wait(1).to({rotation:-397.4395,x:-4.9,y:267.15},0).wait(1).to({rotation:-402.4881,x:-6.85,y:270.8},0).wait(1).to({rotation:-407.3952,x:-8.75,y:274.35},0).wait(1).to({rotation:-412.1668,x:-10.6,y:277.8},0).wait(1).to({rotation:-416.8094,x:-12.3,y:281.25},0).wait(1).to({rotation:-421.3304,x:-14.1,y:284.45},0).wait(1).to({rotation:-425.738,x:-15.75,y:287.65},0).wait(1).to({rotation:-430.041,x:-17.45,y:290.8},0).wait(1).to({rotation:-434.249,x:-19.05,y:293.85},0).wait(1).to({rotation:-438.3726,x:-20.65,y:296.85},0).wait(1).to({rotation:-442.4229,x:-22.2,y:299.8},0).wait(1).to({rotation:-446.4117,x:-23.7,y:302.65},0).wait(1).to({rotation:-450.3516,x:-25.25,y:305.5},0).wait(1).to({rotation:-454.2558,x:-26.7,y:308.35},0).wait(1).to({rotation:-458.1379,x:-28.3,y:311.15},0).wait(1).to({regX:16.4,rotation:-462.0119,x:-29.7,y:314.05},0).wait(356));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.9,-30,206.5,362);


(lib.Symbol67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// l4.png copy 2
	this.instance = new lib.Symbol54();
	this.instance.parent = this;
	this.instance.setTransform(216.2,-30.7,1,1,0,0,0,10.5,11.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(16).to({_off:false},0).wait(1).to({rotation:-14.1281,x:209.55,y:-22.55},0).wait(1).to({rotation:-28.1401,x:202.95,y:-14.5},0).wait(1).to({rotation:-42.0341,x:196.45,y:-6.55},0).wait(1).to({rotation:-55.8079,x:190,y:1.3},0).wait(1).to({rotation:-69.4597,x:183.6,y:9.2},0).wait(1).to({rotation:-82.9873,x:177.25,y:17},0).wait(1).to({rotation:-96.3886,x:171.05,y:24.65},0).wait(1).to({rotation:-109.6614,x:164.75,y:32.3},0).wait(1).to({rotation:-122.8037,x:158.55,y:39.8},0).wait(1).to({rotation:-135.8131,x:152.45,y:47.35},0).wait(1).to({rotation:-148.6875,x:146.5,y:54.75},0).wait(1).to({rotation:-161.4245,x:140.5,y:62.05},0).wait(1).to({rotation:-174.022,x:134.6,y:69.25},0).wait(1).to({rotation:-186.4775,x:128.75,y:76.45},0).wait(1).to({rotation:-198.7887,x:122.95,y:83.5},0).wait(1).to({rotation:-210.9532,x:117.3,y:90.5},0).wait(1).to({rotation:-222.9687,x:111.6,y:97.4},0).wait(1).to({rotation:-234.8328,x:106.1,y:104.25},0).wait(1).to({rotation:-246.543,x:100.55,y:110.95},0).wait(1).to({rotation:-258.097,x:95.2,y:117.6},0).wait(1).to({rotation:-269.4923,x:89.8,y:124.15},0).wait(1).to({rotation:-280.7265,x:84.55,y:130.6},0).wait(1).to({rotation:-291.7973,x:79.35,y:136.95},0).wait(1).to({rotation:-302.7022,x:74.2,y:143.25},0).wait(1).to({rotation:-313.4389,x:69.2,y:149.35},0).wait(1).to({rotation:-324.0051,x:64.3,y:155.45},0).wait(1).to({rotation:-334.3986,x:59.4,y:161.45},0).wait(1).to({rotation:-344.6171,x:54.6,y:167.35},0).wait(1).to({rotation:-354.6584,x:49.9,y:173.1},0).wait(1).to({rotation:-364.5207,x:45.25,y:178.7},0).wait(1).to({rotation:-374.2019,x:40.75,y:184.3},0).wait(1).to({rotation:-383.7002,x:36.25,y:189.8},0).wait(1).to({rotation:-393.0138,x:31.9,y:195.15},0).wait(1).to({rotation:-402.1414,x:27.65,y:200.4},0).wait(1).to({rotation:-411.0814,x:23.45,y:205.5},0).wait(1).to({rotation:-419.8327,x:19.4,y:210.55},0).wait(1).to({rotation:-428.3945,x:15.35,y:215.5},0).wait(1).to({rotation:-436.7659,x:11.45,y:220.3},0).wait(1).to({rotation:-444.9466,x:7.6,y:224.95},0).wait(1).to({rotation:-452.9364,x:3.9,y:229.55},0).wait(1).to({rotation:-460.7356,x:0.25,y:234.05},0).wait(1).to({rotation:-468.3447,x:-3.35,y:238.45},0).wait(1).to({rotation:-475.7648,x:-6.8,y:242.7},0).wait(1).to({rotation:-482.9972,x:-10.2,y:246.85},0).wait(1).to({rotation:-490.0439,x:-13.5,y:250.85},0).wait(1).to({rotation:-496.9073,x:-16.75,y:254.85},0).wait(1).to({rotation:-503.5903,x:-19.85,y:258.65},0).wait(1).to({rotation:-510.0964,x:-22.9,y:262.4},0).wait(1).to({rotation:-516.43,x:-25.85,y:266.05},0).wait(1).to({rotation:-522.5956,x:-28.75,y:269.6},0).wait(1).to({rotation:-528.5989,x:-31.65,y:273.05},0).wait(1).to({rotation:-534.4461,x:-34.35,y:276.4},0).wait(1).to({rotation:-540.1441,x:-37.05,y:279.7},0).wait(1).to({rotation:-545.7006,x:-39.6,y:282.85},0).wait(1).to({rotation:-551.1241,x:-42.15,y:286},0).wait(1).to({rotation:-556.4238,x:-44.6,y:289},0).wait(1).to({rotation:-561.6099,x:-47.05,y:292},0).wait(1).to({rotation:-566.6931,x:-49.45,y:294.95},0).wait(1).to({rotation:-571.685,x:-51.8,y:297.75},0).wait(1).to({rotation:-576.5979,x:-54.1,y:300.6},0).wait(1).to({rotation:-581.4448,x:-56.35,y:303.45},0).wait(1).to({rotation:-586.2394,x:-58.6,y:306.2},0).wait(1).to({rotation:-590.9958,x:-60.85,y:308.9},0).wait(1).to({rotation:-595.7289,x:-63.05,y:311.6},0).wait(1).to({regX:10.6,rotation:-600.4539,x:-65.35,y:314.4},0).wait(166));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.4,-42.2,307.1,371.3);


(lib.Symbol66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol65();
	this.instance.parent = this;
	this.instance.setTransform(19.6,23,1,1,0,0,0,19.6,23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol66, new cjs.Rectangle(0,0,39,46), null);


(lib.Symbol58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol60();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.8398},20).to({alpha:0.6914},11).to({alpha:0.7891},11).to({alpha:0.5508},14).to({alpha:0.6914},12).to({alpha:0},19).to({_off:true},427).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Symbol56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{loop:1});

	// timeline functions:
	this.frame_11 = function() {
		this.gotoAndPlay("loop");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(11).call(this.frame_11).wait(1));

	// Layer_2
	this.instance = new lib.Symbol57();
	this.instance.parent = this;
	this.instance.setTransform(167.6,107.7,1.1387,1.1387,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:129.2,y:435.65},11).wait(1));

	// Layer_1
	this.instance_1 = new lib.Symbol57();
	this.instance_1.parent = this;
	this.instance_1.setTransform(188.55,-220.25,1.1387,1.1387,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:167.6,y:107.7},11).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.3,-362.6,447.1,983.9);


(lib.Symbol55 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Symbol69();
	this.instance.parent = this;
	this.instance.setTransform(101.05,12.1,1,1,0,0,0,3.7,12.1);

	this.instance_1 = new lib.Symbol67();
	this.instance_1.parent = this;
	this.instance_1.setTransform(81.15,12.8,1,1,0,0,0,7.6,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},28).wait(286));

	// Layer_3
	this.instance_2 = new lib.Symbol70();
	this.instance_2.parent = this;
	this.instance_2.setTransform(49.35,11.3,1,1,0,0,0,14.6,11.3);

	this.instance_3 = new lib.Symbol69();
	this.instance_3.parent = this;
	this.instance_3.setTransform(3.7,12.1,1,1,0,0,0,3.7,12.1);

	this.instance_4 = new lib.Symbol67();
	this.instance_4.parent = this;
	this.instance_4.setTransform(36.85,12.8,1,1,0,0,0,7.6,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},8).wait(306));

	// l2
	this.instance_5 = new lib.Symbol69();
	this.instance_5.parent = this;
	this.instance_5.setTransform(3.7,12.1,1,1,0,0,0,3.7,12.1);

	this.instance_6 = new lib.Symbol70();
	this.instance_6.parent = this;
	this.instance_6.setTransform(22.6,11.3,1,1,0,0,0,14.6,11.3);

	this.instance_7 = new lib.Symbol67();
	this.instance_7.parent = this;
	this.instance_7.setTransform(7.6,12.8,1,1,0,0,0,7.6,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5}]}).wait(314));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Symbol39копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(44).call(this.frame_44).wait(22));

	// Слой_16
	this.instance = new lib.Символ14();
	this.instance.parent = this;
	this.instance.setTransform(78.85,105.75,0.0947,0.8686,-11.457,0,0,61.1,68.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).to({regX:60.3,regY:68.8,scaleX:0.8723,scaleY:0.8723,rotation:1.0916,x:17.75,y:122.25},3).to({regY:68.7,rotation:3.8335,x:18.55,y:122.2},4,cjs.Ease.get(-1)).wait(7).to({regX:60.4,rotation:5.8091,x:13.25},5,cjs.Ease.get(-1)).to({regX:60.1,scaleX:2.9595,scaleY:2.9595,rotation:3.8335,x:18.2,y:122.35},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// w_arm1.png
	this.instance_1 = new lib.Symbol45();
	this.instance_1.parent = this;
	this.instance_1.setTransform(30.8,51.45,1,1,0,0,0,30.8,53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:30.7,regY:53.5,scaleX:1.0689,scaleY:1.0689,rotation:-4.7168,x:32,y:58},3).to({regX:30.4,regY:53.6,scaleX:0.8679,scaleY:0.9166,rotation:-21.8894,x:3,y:80.1},3).to({scaleX:0.8666,scaleY:0.9153,rotation:-8.8563,x:-16.1,y:90.85},4).to({regY:53.8,rotation:18.0915,x:-17.9,y:87.45},3,cjs.Ease.get(1)).wait(9).to({rotation:18.0915},0).to({regX:30.3,rotation:4.8707,x:-19.3,y:89.8},5,cjs.Ease.get(-1)).to({regX:30.4,regY:53.6,scaleX:1.776,scaleY:1.8758,rotation:-29.8661,x:-42.4,y:32.3},9,cjs.Ease.get(-1)).wait(21).to({rotation:-29.8661},0).to({_off:true},1).wait(8));

	// w_arm2.png
	this.instance_2 = new lib.Symbol41();
	this.instance_2.parent = this;
	this.instance_2.setTransform(56,113.35,1,1,0,0,0,56,115.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:118.15},3).to({regX:55.9,rotation:-35.232,x:73.3,y:127.2},3).to({regX:56,rotation:-34.7597,x:45.15,y:147.5},4).wait(12).to({x:44.2,y:147.35},5,cjs.Ease.get(-1)).to({regX:55.9,scaleX:2.0464,scaleY:2.0464,rotation:-34.7594,x:73.75,y:147.85},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// w_body.png
	this.instance_3 = new lib.Символ1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(56,70.5,1,1,0,0,0,56,70.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:56.1,regY:70.6,scaleX:0.9687,rotation:-1.8958,x:57.9,y:74.2},3).to({regY:70.5,rotation:-8.8699,x:12.95,y:101.95},7).wait(12).to({regX:56,regY:70.7,rotation:-1.6229,x:9.2,y:103.4},5,cjs.Ease.get(-1)).to({regX:56.1,regY:70.5,scaleX:1.9824,scaleY:2.0464,rotation:-8.8694,x:8.05,y:54.7},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// 11
	this.instance_4 = new lib.Символ8();
	this.instance_4.parent = this;
	this.instance_4.setTransform(42.1,120.9,1,1,0,0,0,17.1,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:17.2,rotation:6.4816,x:48.25,y:123.35},3).to({regX:17.1,rotation:28.968,x:3.3,y:134.4},7).wait(12).to({regY:2.1,scaleX:0.9999,scaleY:0.9999,rotation:41.1778,x:-1.45,y:145.15},5,cjs.Ease.get(-1)).to({regY:2,scaleX:2.0464,scaleY:2.0464,rotation:28.968,x:8.55,y:121.1},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// 22
	this.instance_5 = new lib.Символ9();
	this.instance_5.parent = this;
	this.instance_5.setTransform(74,121.7,1,1,0,0,0,16,3.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regX:16.1,regY:3.8,rotation:0.2055,x:77.65,y:123.65},3).to({rotation:-25.234,x:34.9,y:142.45},7).wait(12).to({scaleX:0.9999,scaleY:0.9999,rotation:-33.2153,x:25.5,y:147},5,cjs.Ease.get(-1)).to({scaleX:2.0464,scaleY:2.0464,rotation:-25.234,x:52.85,y:137.35},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// 33
	this.instance_6 = new lib.Символ10();
	this.instance_6.parent = this;
	this.instance_6.setTransform(35.9,161,1,1,0,0,0,18.9,5);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({rotation:2.1923,x:37.7,y:162.15},3).to({rotation:-11.0162,x:-19.2,y:162.45},7).wait(12).to({regX:18.8,rotation:-27.7174,x:-32.45,y:166.1},5,cjs.Ease.get(-1)).to({scaleX:2.0465,scaleY:2.0465,rotation:-11.0161,x:-37.55,y:178.35},9,cjs.Ease.get(-1)).wait(21).to({rotation:-11.0161},0).to({_off:true},1).wait(8));

	// 44
	this.instance_7 = new lib.Символ11();
	this.instance_7.parent = this;
	this.instance_7.setTransform(77.5,160,1,1,0,0,0,17.5,4);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:17.6,rotation:15.1758,x:81.85,y:160.6},3).to({rotation:-33.5412,x:53.35,y:174.45},7).wait(12).to({regX:17.5,rotation:-37.5286,x:48.85,y:176.15},5,cjs.Ease.get(-1)).to({regX:17.6,regY:4.1,scaleX:2.0464,scaleY:2.0464,rotation:-33.5411,x:90.7,y:202.95},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// 55
	this.instance_8 = new lib.Символ13();
	this.instance_8.parent = this;
	this.instance_8.setTransform(32.8,211.5,1,1,0,0,0,18.8,2.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(3).to({x:-12.1,y:211.8},7).wait(12).to({x:-13.35,y:211.55},5,cjs.Ease.get(-1)).to({scaleX:2.0464,scaleY:2.0464,x:-22.85,y:279.25},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// 66
	this.instance_9 = new lib.Символ12();
	this.instance_9.parent = this;
	this.instance_9.setTransform(83.3,208.8,1,1,0,0,0,13.3,1.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:74.25,y:208.2},3).to({x:82.05},7).wait(17).to({scaleX:2.0464,scaleY:2.0464,x:149.25,y:272},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// new_head
	this.instance_10 = new lib.Symbol66();
	this.instance_10.parent = this;
	this.instance_10.setTransform(52.1,36.9,1,1,-3.4144,0,0,17.6,36.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:52.7,y:41.1},3).to({x:4.35,y:69.45},7).to({rotation:-9.6196,x:4.45},3,cjs.Ease.get(-1)).wait(9).to({rotation:-7.1476,x:3.6,y:73.05},5,cjs.Ease.get(-1)).to({regX:17.5,regY:36.3,scaleX:1.7415,scaleY:1.7415,rotation:-3.4137,x:-6.15,y:-12.05},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// L-hand
	this.instance_11 = new lib.Symbol61();
	this.instance_11.parent = this;
	this.instance_11.setTransform(3.95,71.15,1,1,2.1958,0,0,32.5,32.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({regX:32.4,scaleX:1.0969,scaleY:1.0969,rotation:-21.9207,x:5.35,y:79.9},3).to({regX:32.3,regY:32.1,scaleX:0.9153,scaleY:0.6726,rotation:-102.0156,x:3.3,y:96},3).to({scaleY:0.0797,rotation:-102.009,x:0,y:75.1},2).to({regX:32.1,regY:31.9,scaleX:0.6982,scaleY:0.6982,rotation:-198.0576,x:-2.75,y:114.1},5,cjs.Ease.get(-1)).to({_off:true},1).wait(52));

	// z2_arm.png
	this.instance_12 = new lib.Symbol46_1();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-4.25,82.3,0.6904,0.6904,-51.2953,0,0,54.9,68.8);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(6).to({_off:false},0).to({regX:54.8,scaleX:0.6893,scaleY:0.6893,rotation:-37.6287,x:-8.35,y:82.4},2).to({regX:55,regY:68.9,scaleX:0.6904,scaleY:0.6904,rotation:2.9317,x:-20.45},5,cjs.Ease.get(1)).wait(9).to({rotation:2.9317},0).to({regX:54.9,rotation:6.6762,x:-24.1,y:87.65},5,cjs.Ease.get(-1)).to({regX:54.8,regY:68.8,scaleX:1.441,scaleY:1.441,rotation:2.9317,x:-44.9,y:25.45},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// Symbol 63
	this.instance_13 = new lib.Symbol63();
	this.instance_13.parent = this;
	this.instance_13.setTransform(98.65,71.25,1,1,-0.2273,0,0,6.9,33);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({regY:32.9,scaleX:0.9999,scaleY:0.9999,rotation:154.9445,x:83.25,y:89.5},3).to({regY:32.8,rotation:92.9813,x:84.9,y:79.4},3).to({regX:7,regY:32.6,scaleX:0.9998,scaleY:0.9998,rotation:162.4668,x:53.9,y:95.9},4).to({x:53.1,y:96.7},3,cjs.Ease.get(-1)).wait(9).to({x:48.1,y:103.75},5,cjs.Ease.get(-1)).to({regX:6.9,scaleX:2.0461,scaleY:2.0461,rotation:162.467,x:91.8,y:42.15},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// Symbol 64
	this.instance_14 = new lib.Symbol64();
	this.instance_14.parent = this;
	this.instance_14.setTransform(72.45,53.6,0.8411,1,-2.1609,0,0,7.6,15.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({regX:7.8,scaleX:0.841,scaleY:0.9999,rotation:52.9364,x:83.35,y:58.35},3).to({regX:7.9,rotation:-9.0274,x:57.4,y:64.65},3).to({regX:8,regY:16,rotation:15.2162,x:34.85,y:71.2},4).to({regY:16.1,rotation:21.7058,x:35.6,y:74.2},3,cjs.Ease.get(-1)).wait(9).to({x:32.35,y:76.7},5,cjs.Ease.get(-1)).to({regY:16,scaleX:1.721,scaleY:2.0462,rotation:15.2157,x:52.65,y:-8.4},9,cjs.Ease.get(-1)).wait(21).to({_off:true},1).wait(8));

	// Слой_15
	this.instance_15 = new lib.Символ15();
	this.instance_15.parent = this;
	this.instance_15.setTransform(80.65,97.8,0.4054,0.5936,-4.476,0,0,56.6,61.8);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(3).to({_off:false},0).to({regX:56.9,regY:62,scaleX:0.6925,scaleY:0.6813,rotation:-6.4414,x:96.85,y:97.95},3).to({regX:57.4,scaleX:0.162,scaleY:0.737,rotation:-10.4786,x:74.9,y:105.3},2).to({_off:true},1).wait(57));

	// Symbol 62
	this.instance_16 = new lib.Symbol62();
	this.instance_16.parent = this;
	this.instance_16.setTransform(33.5,59.1,0.8722,1,2.4382,0,0,40.8,20.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({regY:21,scaleX:0.9567,scaleY:1.0969,rotation:-5.5185,x:35.95,y:63.85},3).to({regX:40.6,scaleX:0.7387,scaleY:0.8469,rotation:-58.9334,x:4.15,y:84.25},4).to({_off:true},1).wait(58));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-157.4,-79.3,365.4,398.6);


(lib.Symbol39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// w_arm1.png
	this.instance = new lib.Symbol45();
	this.instance.parent = this;
	this.instance.setTransform(30.75,54.55,1,1,-15.4749,0,0,30.7,53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:30.8,rotation:0,x:30.8,y:51.5},51,cjs.Ease.quadInOut).to({y:53.1},32,cjs.Ease.quadInOut).to({y:51.5},44,cjs.Ease.quadInOut).to({y:54.8},28,cjs.Ease.quadInOut).to({y:51.8},36,cjs.Ease.quadInOut).wait(1).to({regX:28,regY:49.5,x:28,y:47.7},0).wait(11).to({regX:30.8,regY:53.6,x:30.8,y:51.8},0).wait(1).to({regX:28,regY:49.5,x:28,y:47.7},0).wait(2).to({y:47.65},0).wait(1).to({y:47.6},0).wait(1).to({y:47.55},0).wait(1).to({y:47.5},0).wait(1).to({y:47.45},0).wait(2).to({y:47.4},0).wait(2).to({y:47.35},0).wait(13).to({regX:30.8,regY:53.6,x:30.8,y:51.45},0).wait(112));

	// w_arm2.png
	this.instance_1 = new lib.Symbol41();
	this.instance_1.parent = this;
	this.instance_1.setTransform(56,116.75,1,1,0,0,0,56,115.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({y:114},51,cjs.Ease.quadInOut).to({y:115.6},32,cjs.Ease.quadInOut).to({y:114},44,cjs.Ease.quadInOut).to({y:116.7},28,cjs.Ease.quadInOut).to({y:113.7},36,cjs.Ease.quadInOut).to({y:113.35},36,cjs.Ease.backInOut).wait(112));

	// w_arm22.png
	this.instance_2 = new lib.Symbol47();
	this.instance_2.parent = this;
	this.instance_2.setTransform(85.4,84.75,0.9994,0.9994,-9.4563,0,0,88.5,81.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:81.6,scaleX:1,scaleY:1,rotation:21.521,x:95.55,y:71.15},51,cjs.Ease.quadInOut).to({regY:81.5,scaleX:0.9988,scaleY:0.922,rotation:28.986,x:93.55,y:72.55},32,cjs.Ease.quadInOut).to({regY:81.6,scaleX:1,scaleY:1,rotation:21.521,x:95.55,y:71.15},44,cjs.Ease.quadInOut).to({regX:88.4,regY:81.5,rotation:-16.6755,x:83.1,y:83.9},28,cjs.Ease.quadInOut).to({scaleX:0.9999,scaleY:0.9999,rotation:-70.3465,x:92.2,y:77.9,alpha:0},17,cjs.Ease.quadIn).to({_off:true},1).wait(166));

	// w_arm12.png
	this.instance_3 = new lib.Symbol44();
	this.instance_3.parent = this;
	this.instance_3.setTransform(19.9,80.2,0.9992,0.9992,19.7047,0,0,15.3,75.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1,scaleY:1,rotation:-28.9891,x:11.35,y:73.75},51,cjs.Ease.quadInOut).to({regX:15.2,regY:76,scaleX:0.9986,scaleY:0.9075,rotation:-30.5856,x:12.95,y:75.9},32,cjs.Ease.quadInOut).to({regX:15.3,regY:75.9,scaleX:1,scaleY:1,rotation:-28.9891,x:11.35,y:73.75},44,cjs.Ease.quadInOut).to({regX:15.4,rotation:15.2011,x:19.85,y:79.4},28,cjs.Ease.quadInOut).to({regX:15.5,rotation:76.1173,x:10.1,y:77.3,alpha:0},17,cjs.Ease.quadIn).to({_off:true},1).wait(166));

	// w_body.png
	this.instance_4 = new lib.Symbol48();
	this.instance_4.parent = this;
	this.instance_4.setTransform(56,115.5,1,1,0,0,0,56,115.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(339));

	// w_arm2b.png
	this.instance_5 = new lib.Symbol42();
	this.instance_5.parent = this;
	this.instance_5.setTransform(56,116.75,1,1,0,0,0,56,115.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({y:114},51,cjs.Ease.quadInOut).to({y:115.6},32,cjs.Ease.quadInOut).to({y:114},44,cjs.Ease.quadInOut).to({y:116.7},28,cjs.Ease.quadInOut).to({y:113.7},36,cjs.Ease.quadInOut).to({y:113.35},36,cjs.Ease.backInOut).wait(112));

	// w_arm21.png
	this.instance_6 = new lib.Symbol46();
	this.instance_6.parent = this;
	this.instance_6.setTransform(73,58.6,0.9993,0.9993,5.1802,0,0,73,57.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({regY:57.2,scaleX:1,scaleY:1,rotation:-26.7078,x:73.1,y:57.25},51,cjs.Ease.quadInOut).to({scaleX:0.9986,scaleY:0.9986,rotation:-20.8633,x:73.25,y:57.3},32,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,rotation:-26.7078,x:73.1,y:57.25},44,cjs.Ease.quadInOut).to({rotation:9.9974,y:57.3},28,cjs.Ease.quadInOut).to({scaleX:0.9999,scaleY:0.9999,rotation:-15.4542,x:73.15,y:57.4,alpha:0},17,cjs.Ease.quadIn).to({_off:true},1).wait(166));

	// new_head
	this.instance_7 = new lib.Symbol66();
	this.instance_7.parent = this;
	this.instance_7.setTransform(50.75,36.85,1,1,-4.9756,0,0,17.6,36.5);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(156).to({_off:false},0).wait(1).to({regX:19.5,regY:23,rotation:-4.9474,x:51.5,y:23.2,alpha:0.0071},0).wait(1).to({rotation:-4.8958,x:51.45,y:23.25,alpha:0.0202},0).wait(1).to({rotation:-4.8193,x:51.5,y:23.2,alpha:0.0396},0).wait(1).to({rotation:-4.716,x:51.55,y:23.25,alpha:0.0658},0).wait(1).to({rotation:-4.5844,y:23.3,alpha:0.0991},0).wait(1).to({rotation:-4.4227,alpha:0.1401},0).wait(1).to({rotation:-4.2292,x:51.65,y:23.25,alpha:0.1892},0).wait(1).to({rotation:-4.0026,x:51.7,y:23.3,alpha:0.2466},0).wait(1).to({rotation:-3.7418,x:51.75,alpha:0.3127},0).wait(1).to({rotation:-3.4461,x:51.85,alpha:0.3877},0).wait(1).to({rotation:-3.1156,x:51.9,alpha:0.4714},0).wait(1).to({rotation:-2.7517,x:52,alpha:0.5636},0).wait(1).to({rotation:-2.3566,x:52.1,y:23.4,alpha:0.6638},0).wait(1).to({rotation:-1.9342,x:52.25,alpha:0.7708},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-1.4897,x:52.35,alpha:0.8835},0).wait(1).to({regX:17.6,regY:36.5,rotation:-1.03,x:50.75,y:36.95,alpha:1},0).wait(1).to({regX:19.5,regY:23,rotation:-0.5447,x:52.5,y:23.35},0).wait(1).to({rotation:-0.0599,x:52.65,y:23.4},0).wait(1).to({scaleX:1,scaleY:1,rotation:0.4161,x:52.85},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:0.8759,x:52.95},0).wait(1).to({scaleX:1,scaleY:1,rotation:1.3131,x:53.05,y:23.45},0).wait(1).to({rotation:1.723,x:53.2,y:23.5},0).wait(1).to({rotation:2.1022,x:53.3},0).wait(1).to({rotation:2.4488,x:53.4,y:23.55},0).wait(1).to({rotation:2.7619,x:53.5,y:23.5},0).wait(1).to({rotation:3.0416,x:53.55},0).wait(1).to({rotation:3.2885,x:53.65},0).wait(1).to({rotation:3.5037,x:53.7,y:23.55},0).wait(1).to({rotation:3.6885,x:53.75},0).wait(1).to({rotation:3.8445,x:53.8},0).wait(1).to({rotation:3.9733,x:53.85},0).wait(1).to({rotation:4.0764},0).wait(1).to({rotation:4.1554,x:53.9},0).wait(1).to({rotation:4.2117,y:23.6},0).wait(1).to({regX:17.6,regY:36.5,rotation:4.2467,x:51.1,y:36.9},0).to({regY:36.4,rotation:-3.4144,x:52.1},36).wait(112));

	// w_head.png
	this.instance_8 = new lib.Symbol40();
	this.instance_8.parent = this;
	this.instance_8.setTransform(51.5,41.5,0.9999,0.9999,1.2513,0,0,51.4,41.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({regX:51.5,scaleX:1,scaleY:1,rotation:10.0489,x:51.55,y:41.65},51,cjs.Ease.quadInOut).to({regX:51.6,rotation:2.5678,x:51.65,y:41.7},32,cjs.Ease.quadInOut).to({regX:51.4,rotation:6.0746,x:51.45,y:41.6},44,cjs.Ease.quadInOut).to({regY:41.5,rotation:-6.0701,x:51.5,y:41.55},28,cjs.Ease.quadInOut).to({_off:true},18).wait(166));

	// w_arm11.png
	this.instance_9 = new lib.Symbol43();
	this.instance_9.parent = this;
	this.instance_9.setTransform(28.75,61.5,0.9996,0.9996,-3.7093,0,0,27.4,59.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({scaleX:1,scaleY:1,rotation:15.7456,x:27.35,y:59.5},51,cjs.Ease.quadInOut).to({regX:27.6,regY:59.4,scaleX:0.9991,scaleY:0.9991,rotation:6.8532,x:27.65,y:59.65},32,cjs.Ease.quadInOut).to({regX:27.4,regY:59.5,scaleX:1,scaleY:1,rotation:15.7456,x:27.35,y:59.5},44,cjs.Ease.quadInOut).to({regX:27.5,rotation:-14.2447,x:27.55},28,cjs.Ease.quadInOut).to({regX:27.6,rotation:13.3986,x:27.65,y:59.6,alpha:0},17,cjs.Ease.quadIn).to({_off:true},1).wait(166));

	// Symbol 61
	this.instance_10 = new lib.Symbol61();
	this.instance_10.parent = this;
	this.instance_10.setTransform(20.2,81.25,0.9999,0.9999,-131.6126,0,0,32.5,32);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(156).to({_off:false},0).wait(1).to({regX:20,regY:23,rotation:-131.1842,x:21.6,y:96.5,alpha:0.0108},0).wait(1).to({rotation:-130.4005,x:21.3,y:96.45,alpha:0.0305},0).wait(1).to({rotation:-129.237,x:20.8,y:96.35,alpha:0.0597},0).wait(1).to({rotation:-127.6681,x:20.15,y:96.2,alpha:0.0991},0).wait(1).to({rotation:-125.6678,x:19.3,y:96.05,alpha:0.1494},0).wait(1).to({rotation:-123.2101,x:18.3,y:95.75,alpha:0.2111},0).wait(1).to({rotation:-120.2703,x:17,y:95.45,alpha:0.285},0).wait(1).to({rotation:-116.8265,x:15.6,y:94.95,alpha:0.3715},0).wait(1).to({rotation:-112.862,x:14,y:94.35,alpha:0.4711},0).wait(1).to({rotation:-108.3678,x:12.2,y:93.65,alpha:0.584},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:-103.3463,x:10.15,y:92.7,alpha:0.7102},0).wait(1).to({rotation:-97.815,x:8,y:91.5,alpha:0.8491},0).wait(1).to({regX:32.5,regY:32,rotation:-91.8104,x:14.25,y:77.35,alpha:1},0).wait(1).to({regX:20,regY:23,rotation:-86.2852,x:3.5,y:88.9},0).wait(1).to({rotation:-80.4723,x:1.35,y:87.45},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-74.4592,x:-0.8,y:85.85},0).wait(1).to({rotation:-68.3461,x:-2.85,y:84.15},0).wait(1).to({rotation:-62.2394,x:-4.75,y:82.3},0).wait(1).to({rotation:-56.2435,x:-6.45,y:80.5},0).wait(1).to({rotation:-50.4527,x:-7.9,y:78.65},0).wait(1).to({rotation:-44.9457,x:-9.2,y:76.85},0).wait(1).to({rotation:-39.783,x:-10.3,y:75.1},0).wait(1).to({rotation:-35.0065,x:-11.15,y:73.6},0).wait(1).to({rotation:-30.6408,x:-11.9,y:72.1},0).wait(1).to({scaleX:1,scaleY:1,rotation:-26.6967,x:-12.45,y:70.8},0).wait(1).to({rotation:-23.174,x:-12.85,y:69.7},0).wait(1).to({rotation:-20.0642,x:-13.2,y:68.65},0).wait(1).to({rotation:-17.3538,x:-13.5,y:67.8},0).wait(1).to({rotation:-15.0254,x:-13.7,y:67.05},0).wait(1).to({rotation:-13.0602,x:-13.8,y:66.45},0).wait(1).to({rotation:-11.4383,x:-13.95,y:65.95},0).wait(1).to({rotation:-10.1398,x:-14,y:65.6},0).wait(1).to({rotation:-9.1452,x:-14.1,y:65.2},0).wait(1).to({rotation:-8.4361,x:-14.15,y:65},0).wait(1).to({regX:32.5,regY:32.1,rotation:-7.9948,x:-0.65,y:72.15},0).to({regY:32.2,rotation:2.1958,x:3.95,y:71.15},41,cjs.Ease.quadInOut).to({_off:true},102).wait(5));

	// Symbol 63
	this.instance_11 = new lib.Symbol63();
	this.instance_11.parent = this;
	this.instance_11.setTransform(87.75,86.05,1,1,133.9916,0,0,6.9,32.9);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(156).to({_off:false},0).wait(1).to({regX:19,regY:23,rotation:133.5672,x:86.6,y:101.55,alpha:0.0108},0).wait(1).to({rotation:132.7905,x:86.9,alpha:0.0305},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:131.6375,x:87.4,y:101.35,alpha:0.0597},0).wait(1).to({rotation:130.0827,x:88,y:101.2,alpha:0.0991},0).wait(1).to({rotation:128.1004,x:88.85,y:100.95,alpha:0.1494},0).wait(1).to({rotation:125.6649,x:89.75,y:100.65,alpha:0.2111},0).wait(1).to({rotation:122.7516,x:90.95,y:100.2,alpha:0.285},0).wait(1).to({rotation:119.3388,x:92.35,y:99.65,alpha:0.3715},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:115.41,x:93.9,y:98.95,alpha:0.4711},0).wait(1).to({rotation:110.9563,x:95.65,y:98.1,alpha:0.584},0).wait(1).to({rotation:105.98,x:97.55,y:96.95,alpha:0.7102},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:100.4985,x:99.65,y:95.65,alpha:0.8491},0).wait(1).to({regX:6.9,regY:32.8,rotation:94.548,x:92.95,y:81.2,alpha:1},0).wait(1).to({regX:19,regY:23,rotation:89.3844,x:103.65,y:92.7},0).wait(1).to({rotation:83.9519,x:105.65,y:91.25},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:78.3323,x:107.55,y:89.65},0).wait(1).to({rotation:72.6192,x:109.3,y:87.95},0).wait(1).to({rotation:66.9122,x:111.05,y:86.1},0).wait(1).to({rotation:61.3087,x:112.55,y:84.3},0).wait(1).to({rotation:55.8968,x:113.9,y:82.5},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:50.7502,x:115.05,y:80.7},0).wait(1).to({rotation:45.9254,x:116,y:79},0).wait(1).to({rotation:41.4614,x:116.8,y:77.45},0).wait(1).to({rotation:37.3814,x:117.45,y:76},0).wait(1).to({rotation:33.6954,x:117.95,y:74.7},0).wait(1).to({scaleX:1,scaleY:1,rotation:30.4032,x:118.4,y:73.5},0).wait(1).to({rotation:27.4969,x:118.7,y:72.5},0).wait(1).to({rotation:24.9639,x:118.9,y:71.6},0).wait(1).to({rotation:22.7879,x:119.1,y:70.85},0).wait(1).to({rotation:20.9513,x:119.3,y:70.25},0).wait(1).to({rotation:19.4355,x:119.35,y:69.7},0).wait(1).to({rotation:18.222,x:119.45,y:69.35},0).wait(1).to({rotation:17.2925,x:119.5,y:69},0).wait(1).to({rotation:16.6298,y:68.8},0).wait(1).to({regX:6.9,regY:33,rotation:16.2174,x:105.3,y:74.8},0).to({rotation:-0.2273,x:98.65,y:71.25},41,cjs.Ease.quadInOut).to({_off:true},102).wait(5));

	// Symbol 64
	this.instance_12 = new lib.Symbol64();
	this.instance_12.parent = this;
	this.instance_12.setTransform(76.35,53.6,1,1,44.9073,0,0,7.6,15.7);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(156).to({_off:false},0).wait(1).to({regX:23.5,regY:23,scaleX:0.9999,scaleY:0.9999,rotation:44.7585,x:82.45,y:70,alpha:0.0108},0).wait(1).to({rotation:44.4864,x:82.5,y:69.95,alpha:0.0305},0).wait(1).to({rotation:44.0823,x:82.65,y:69.9,alpha:0.0597},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:43.5375,x:82.75,y:69.85,alpha:0.0991},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:42.8428,x:82.9,y:69.8,alpha:0.1494},0).wait(1).to({scaleX:0.9996,scaleY:0.9996,rotation:41.9893,x:83,y:69.65,alpha:0.2111},0).wait(1).to({scaleX:0.9995,scaleY:0.9995,rotation:40.9684,x:83.3,y:69.55,alpha:0.285},0).wait(1).to({scaleX:0.9994,scaleY:0.9994,rotation:39.7725,x:83.5,y:69.35,alpha:0.3715},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:38.3957,x:83.8,y:69.2,alpha:0.4711},0).wait(1).to({scaleX:0.9991,scaleY:0.9991,rotation:36.835,x:84.05,y:69,alpha:0.584},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,rotation:35.0912,x:84.4,y:68.7,alpha:0.7102},0).wait(1).to({scaleX:0.9987,scaleY:0.9987,rotation:33.1703,x:84.8,y:68.4,alpha:0.8491},0).wait(1).to({regX:7.7,regY:15.7,scaleX:0.9985,scaleY:0.9985,rotation:31.0851,x:75.4,y:53.6,alpha:1},0).wait(1).to({regX:23.5,regY:23,scaleX:0.9986,scaleY:0.9986,rotation:29.5138,x:85.3,y:67.75},0).wait(1).to({scaleX:0.9987,scaleY:0.9987,rotation:27.8608,x:85.5,y:67.4},0).wait(1).to({scaleX:0.9988,scaleY:0.9988,rotation:26.1507,x:85.7,y:67.1},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,rotation:24.4123,x:85.9,y:66.75},0).wait(1).to({scaleX:0.999,scaleY:0.999,rotation:22.6757,x:86.05,y:66.4},0).wait(1).to({scaleX:0.9991,scaleY:0.9991,rotation:20.9705,x:86.25,y:66.05},0).wait(1).to({scaleX:0.9992,scaleY:0.9992,rotation:19.3237,x:86.35,y:65.7},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:17.7576,x:86.5,y:65.35},0).wait(1).to({scaleX:0.9994,scaleY:0.9994,rotation:16.2895,x:86.65,y:65},0).wait(1).to({scaleX:0.9995,scaleY:0.9995,rotation:14.9311,x:86.75,y:64.65},0).wait(1).to({scaleX:0.9996,scaleY:0.9996,rotation:13.6896,y:64.4},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:12.568,x:86.9,y:64.1},0).wait(1).to({rotation:11.5662,y:63.9},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:10.6818,x:87,y:63.65},0).wait(1).to({rotation:9.911,x:87.05,y:63.45},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:9.2489,y:63.3},0).wait(1).to({rotation:8.69,x:87.1,y:63.15},0).wait(1).to({scaleX:1,scaleY:1,rotation:8.2288,y:63},0).wait(1).to({rotation:7.8595,y:62.95},0).wait(1).to({rotation:7.5767,y:62.85},0).wait(1).to({rotation:7.375,y:62.8},0).wait(1).to({regX:7.5,regY:15.8,rotation:7.2495,x:72.4,y:53.6},0).to({regX:7.6,scaleX:0.8411,rotation:-2.1609,x:72.45},41,cjs.Ease.quadInOut).to({_off:true},102).wait(5));

	// Symbol 62
	this.instance_13 = new lib.Symbol62();
	this.instance_13.parent = this;
	this.instance_13.setTransform(27.4,58.4,1,1,-56.8592,0,0,40.6,20.8);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(156).to({_off:false},0).wait(1).to({regX:27.5,regY:23,scaleX:0.9999,scaleY:0.9999,rotation:-56.6786,x:22.05,y:70.55,alpha:0.0108},0).wait(1).to({rotation:-56.3483,x:22.1,alpha:0.0305},0).wait(1).to({rotation:-55.8578,x:22.05,y:70.5,alpha:0.0597},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:-55.1964,x:21.95,y:70.4,alpha:0.0991},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:-54.3532,x:21.8,y:70.35,alpha:0.1494},0).wait(1).to({scaleX:0.9996,scaleY:0.9996,rotation:-53.3172,x:21.7,y:70.3,alpha:0.2111},0).wait(1).to({scaleX:0.9995,scaleY:0.9995,rotation:-52.0779,x:21.6,y:70.15,alpha:0.285},0).wait(1).to({scaleX:0.9994,scaleY:0.9994,rotation:-50.6262,x:21.4,y:70,alpha:0.3715},0).wait(1).to({scaleX:0.9992,scaleY:0.9992,rotation:-48.955,x:21.25,y:69.85,alpha:0.4711},0).wait(1).to({scaleX:0.999,scaleY:0.999,rotation:-47.0605,x:21,y:69.6,alpha:0.584},0).wait(1).to({scaleX:0.9988,scaleY:0.9988,rotation:-44.9437,x:20.9,y:69.35,alpha:0.7102},0).wait(1).to({scaleX:0.9985,scaleY:0.9985,rotation:-42.612,x:20.65,y:69.05,alpha:0.8491},0).wait(1).to({regX:40.6,regY:20.8,scaleX:0.9983,scaleY:0.9983,rotation:-40.0808,x:29,y:58.7,alpha:1},0).wait(1).to({regX:27.5,regY:23,scaleX:0.9984,scaleY:0.9984,rotation:-37.7653,x:20.35,y:68.45},0).wait(1).to({scaleX:0.9985,scaleY:0.9985,rotation:-35.3293,x:20.25,y:68.05},0).wait(1).to({scaleX:0.9987,scaleY:0.9987,rotation:-32.8093,x:20.2,y:67.65},0).wait(1).to({scaleX:0.9988,scaleY:0.9988,rotation:-30.2474,x:20.1,y:67.25},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,rotation:-27.6882,x:20.05,y:66.85},0).wait(1).to({scaleX:0.999,scaleY:0.999,rotation:-25.1755,x:20,y:66.4},0).wait(1).to({scaleX:0.9992,scaleY:0.9992,rotation:-22.7486,x:20.05,y:66},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:-20.4408,y:65.55},0).wait(1).to({scaleX:0.9994,scaleY:0.9994,rotation:-18.2772,y:65.15},0).wait(1).to({scaleX:0.9995,scaleY:0.9995,rotation:-16.2754,x:20.15,y:64.7},0).wait(1).to({scaleX:0.9996,scaleY:0.9996,rotation:-14.4459,y:64.35},0).wait(1).to({rotation:-12.793,x:20.2,y:64},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:-11.3167,x:20.25,y:63.75},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:-10.0134,x:20.3,y:63.45},0).wait(1).to({rotation:-8.8775,x:20.35,y:63.2},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:-7.9018,x:20.45,y:63},0).wait(1).to({rotation:-7.0782,x:20.5,y:62.8},0).wait(1).to({rotation:-6.3985,x:20.55,y:62.7},0).wait(1).to({scaleX:1,scaleY:1,rotation:-5.8543,y:62.6},0).wait(1).to({rotation:-5.4375,x:20.65,y:62.5},0).wait(1).to({rotation:-5.1403,x:20.6,y:62.45},0).wait(1).to({regX:40.8,regY:20.9,rotation:-4.9554,x:33.5,y:59.1},0).to({scaleX:0.8722,rotation:2.4382},41,cjs.Ease.quadInOut).to({_off:true},102).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.1,-39.5,385,300.8);


(lib.Symbol73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logo
	this.instance = new lib.Символ18();
	this.instance.parent = this;
	this.instance.setTransform(0,-123.65,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(237).to({alpha:0},7).wait(47));

	// bottom_line
	this.instance_1 = new lib.Символ17();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-124.65,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(237).to({alpha:0},7).wait(47));

	// rain
	this.instance_2 = new lib.Symbol56();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,-175,1,1,0,0,0,150,125);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(136).to({_off:false},0).to({alpha:1},15).wait(43).to({alpha:0},16).to({_off:true},1).wait(80));

	// night
	this.instance_3 = new lib.Symbol50();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,-175,1,1,0,0,0,150,125);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(124).to({_off:false},0).to({alpha:0.25},27).wait(52).to({alpha:0},30).to({_off:true},1).wait(57));

	// sunlight
	this.instance_4 = new lib.Symbol58();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,-175,1,1,0,0,0,150,125);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1).to({_off:false},0).wait(290));

	// leaves
	this.instance_5 = new lib.Symbol55();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-127.3,-287.7,1,1,0,0,0,22.7,12.3);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(55).to({_off:false},0).to({_off:true},96).wait(140));

	// warrior
	this.instance_6 = new lib.Symbol39("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(36.85,-174.55,1,1,0,0,0,56,115.5);

	this.instance_7 = new lib.Symbol39копия("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(35.65,-170.05,1,1,0,0,0,54.8,120);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},233).wait(58));

	// Layer_15
	this.instance_8 = new lib.Symbol74("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(0.05,-50.6,1,1,0,0,0,150,50.1);
	this.instance_8.alpha = 0.6484;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(291));

	// bg2
	this.instance_9 = new lib.Symbol49();
	this.instance_9.parent = this;
	this.instance_9.setTransform(0,-175,1,1,0,0,0,150,125);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(105).to({_off:false},0).to({alpha:1},67).wait(31).to({alpha:0},30).to({_off:true},1).wait(57));

	// bg1
	this.instance_10 = new lib.Symbol72("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(225,-175,1,1,0,0,0,375,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(291));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-450,-662.6,1050,691.7);


// stage content:
(lib._1812085xlp300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_398 = function() {
		if ( ! this.alreadyExecuted) {
		  this.alreadyExecuted = true;
		  this.loopNumber = 1;
		} else {
		  this.loopNumber++;
		  if (this.loopNumber == 2) {
		    this.stop();
		  }
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(398).call(this.frame_398).wait(22));

	// Layer_1
	this.instance = new lib.Symbol76("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(150,300,1,1,0,0,0,150,300);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(412).to({_off:false},0).to({alpha:1},7).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3dXtMAAAgvZMAu7AAAMAAAAvZg");
	mask.setTransform(150.175,148.7);

	// A
	this.instance_1 = new lib.Symbol73("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(264.55,348.1,1,1,0,0,0,114.5,48.1);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(269).to({startPosition:279},0).to({alpha:0,startPosition:289},7).wait(144));

	// BOTTOM
	this.instance_2 = new lib.Symbol71("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(200.1,675,1,1,0,0,0,50.1,51);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(276).to({startPosition:105},0).to({y:503.9},8,cjs.Ease.get(1)).wait(136));

	// bg5
	this.instance_3 = new lib.Symbol9();
	this.instance_3.parent = this;
	this.instance_3.setTransform(150,438.5,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(276).to({regX:149.9,scaleX:1.2693,scaleY:1.4004,x:149.9,y:245.45},8,cjs.Ease.get(1)).wait(136));

	// BG0
	this.instance_4 = new lib.Symbol75("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(420));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(109.7,297,230.8,336.5);
// library properties:
lib.properties = {
	id: 'D989D54A625F9644B2784B6617044FF1',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"181208_5xlp_300x600_atlas_P_.png?1546590668685", id:"181208_5xlp_300x600_atlas_P_"},
		{src:"181208_5xlp_300x600_atlas_NP_.jpg?1546590668685", id:"181208_5xlp_300x600_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D989D54A625F9644B2784B6617044FF1'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;