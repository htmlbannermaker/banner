(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"181208_adtr_300x250_atlas_P_", frames: [[975,199,40,195],[906,400,59,199],[906,199,67,199],[906,0,89,197],[196,1245,142,186],[340,1405,132,164],[340,1245,143,158],[800,993,194,235],[604,756,194,235],[0,252,300,250],[0,1008,194,235],[302,252,300,250],[196,1008,194,235],[604,252,300,250],[800,756,194,235],[392,1008,194,235],[604,993,194,235],[588,1230,194,235],[784,1230,194,235],[0,1245,194,235],[0,504,300,250],[302,756,300,250],[302,504,300,250],[0,756,300,250],[604,504,300,250],[302,0,300,250],[604,0,300,250],[0,0,300,250]]},
		{name:"181208_adtr_300x250_atlas_NP_", frames: [[0,0,300,250],[0,252,300,250]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._6 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._7 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Arm1 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Arm2 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.bg = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.bg_norust = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bg_rust = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Body = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.cta = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Head = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.label = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Leg11 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Leg12 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Leg13 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Leg22 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Leg23 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Leg_21 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.legal = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.p1 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.p2 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.p3 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.t11 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.t12 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.t13 = function() {
	this.initialize(ss["181208_adtr_300x250_atlas_P_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._7();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,143,158);


(lib.Symbol53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,40,195);


(lib.Symbol52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Symbol39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol39, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0.729,1],0,0,0,0,0,17.1).s().dr(-18.25,-37.25,36.5,74.5);
	this.shape.setTransform(64.8134,64.8337,0.6296,4.4751,90);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0.729,1],0,0,0,0,0,17.1).s().dr(-18.25,-37.25,36.5,74.5);
	this.shape_1.setTransform(64.8476,64.9866,0.6268,4.4751);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol37, new cjs.Rectangle(-101.9,-101.7,333.4,333.4), null);


(lib.Symbol35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,231,169,0)","#FFE7A9","rgba(255,231,169,0)"],[0,0.498,1],-21.3,0,21.4,0).s().dr(-21.4,-30.4,42.8,60.8);
	this.shape.setTransform(34.5245,37.1149,1,1,33.2289);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol35, new cjs.Rectangle(0,0,69.1,74.2), null);


(lib.Symbol32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol32, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.legal();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol31, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg12();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,194,235);


(lib.Symbol21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg23();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol21, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg22();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol20, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg13();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol19, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol17, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Leg_21();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol16, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.label();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Head();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol14, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.cta();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Body();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg_rust();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol11, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg_norust();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Arm2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Arm1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0,194,235), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.t13();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.t12();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.t11();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.p2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol53("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(60.65,73.5,1,1,0,0,0,20,97.5);

	this.instance_1 = new lib._2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-18,-28);

	this.instance_2 = new lib._3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-25,-28);

	this.instance_3 = new lib._4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-48,-26);

	this.instance_4 = new lib._5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-101,-15);

	this.instance_5 = new lib._6();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-91,7);

	this.instance_6 = new lib.Symbol54("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-30.5,92,1,1,0,0,0,71.5,79);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_6}]},14).to({state:[{t:this.instance_6}]},15).to({state:[{t:this.instance_6}]},7).to({state:[]},1).wait(99));
	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:20},3,cjs.Ease.get(-1)).to({_off:true},2).wait(146));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(15).to({_off:false},0).wait(14).to({startPosition:0},0).to({regX:71.4,regY:78.9,scaleX:2.8792,scaleY:2.8792,rotation:5.2309,x:-7.1,y:92.1},15,cjs.Ease.get(1)).wait(7).to({startPosition:0},0).to({_off:true},1).wait(99));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-232.5,-152.9,451.4,490.6);


(lib.Symbol36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol37();
	this.instance.parent = this;
	this.instance.setTransform(65.05,65.05,0.4163,0.4163,0,0,0,65.3,65.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFFFF","rgba(255,255,255,0)"],[0,1],0,0,0,0,0,53.8).s().p("Al4F5QidicAAjdQAAjcCdidQCcicDcAAQDdAACcCcQCdCdAADcQAADdidCcQicCdjdAAQjcAAicidg");
	this.shape.setTransform(64.35,64.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(30));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.5,-4.5,138.7,138.8);


(lib.Symbol33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Leg12.png
	this.instance = new lib.Symbol25("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(12.95,179.35,1,1,-5.4971,0,0,64,188.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.9984,scaleY:0.9984,rotation:1.7805,x:74.25,y:186.25},14,cjs.Ease.quadIn).to({regY:188.1,scaleX:1,scaleY:1,rotation:-91.4384,x:97.8,y:179.85},13,cjs.Ease.quadOut).to({regX:64.2,rotation:0,x:64.2,y:188.1},16,cjs.Ease.quadIn).to({regX:64,regY:188.2,rotation:-5.4971,x:12.95,y:179.35},16,cjs.Ease.quadOut).wait(1));

	// Symbol 17
	this.instance_1 = new lib.Symbol17();
	this.instance_1.parent = this;
	this.instance_1.setTransform(57.65,135.95,0.999,0.999,60.715,0,0,58.8,131.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:58.6,scaleX:0.9995,scaleY:0.9995,rotation:-10.1625,x:57.6,y:136},14,cjs.Ease.quadIn).to({regX:58.4,regY:131.9,scaleX:0.9999,scaleY:0.9999,rotation:-31.4857,y:135.9},13,cjs.Ease.quadOut).to({regX:58.6,regY:131.8,scaleX:1,scaleY:1,rotation:0,x:57.55,y:135.6},16,cjs.Ease.quadIn).to({regX:58.8,scaleX:0.999,scaleY:0.999,rotation:60.715,x:57.65,y:135.95},16,cjs.Ease.quadOut).wait(1));

	// Symbol 19
	this.instance_2 = new lib.Symbol19();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-19.05,211.4,0.9995,0.9995,9.0515,0,0,30.9,211.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:0.9998,scaleY:0.9998,rotation:57.522,x:42.95,y:213.45},14,cjs.Ease.quadIn).wait(1).to({regX:97,regY:117.5,scaleX:0.9995,scaleY:0.9995,rotation:49.908,x:169.25,y:206.3},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:42.3191,x:178.45,y:194.2},0).wait(1).to({scaleX:0.999,scaleY:0.999,rotation:35.1482,x:185.35,y:183.3},0).wait(1).to({scaleX:0.9988,scaleY:0.9988,rotation:28.6872,x:190.15,y:173.9},0).wait(1).to({regX:30.9,regY:211.8,scaleX:0.9987,scaleY:0.9987,rotation:23.0789,x:95.65,y:227.05},0).wait(1).to({regX:97,regY:117.5,scaleX:0.999,scaleY:0.999,rotation:17.6616,x:195.5,y:154.2},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:13.217,x:196.65,y:144.75},0).wait(1).to({scaleX:0.9995,scaleY:0.9995,rotation:9.6386,x:197.3,y:137.55},0).wait(1).to({scaleX:0.9997,scaleY:0.9997,rotation:6.8146,x:197.5,y:132},0).wait(1).to({scaleX:0.9998,scaleY:0.9998,rotation:4.6419,x:197.55,y:127.9},0).wait(1).to({scaleX:0.9999,scaleY:0.9999,rotation:3.0309,y:124.95},0).wait(1).to({scaleX:1,scaleY:1,rotation:1.9058,x:197.5,y:122.95},0).wait(1).to({regX:30.9,regY:211.8,rotation:1.2031,x:129.4,y:214.6},0).to({rotation:0,x:29.85,y:215.6},16,cjs.Ease.quadIn).to({scaleX:0.9995,scaleY:0.9995,rotation:9.0515,x:-19.05,y:211.4},16,cjs.Ease.quadOut).wait(1));

	// 2
	this.instance_3 = new lib.Symbol20();
	this.instance_3.parent = this;
	this.instance_3.setTransform(116.2,170.9,1,1,8.1699,0,0,119.7,164.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:119.5,rotation:31.7908,x:86.55,y:179.6},15,cjs.Ease.quadIn).to({regY:164.2,rotation:32.9903,x:54.45,y:168.15},15,cjs.Ease.quadOut).to({regX:119.6,regY:164.1,scaleX:0.9999,scaleY:0.9999,rotation:16.4425,x:107.15,y:174.9},15,cjs.Ease.quadIn).to({regX:119.7,scaleX:1,scaleY:1,rotation:8.1699,x:116.2,y:170.9},14,cjs.Ease.quadOut).wait(1));

	// 1
	this.instance_4 = new lib.Symbol16();
	this.instance_4.parent = this;
	this.instance_4.setTransform(83.75,132.45,1,1,7.2364,0,0,83.7,132.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:83.6,regY:132.3,rotation:48.7732,x:83.65,y:132.5},15,cjs.Ease.quadIn).to({regX:83.7,regY:132.4,rotation:92.2658,x:83.7,y:132.55},15,cjs.Ease.quadOut).to({regY:132.5,rotation:26.1912,x:83.8,y:132.65},15,cjs.Ease.quadIn).to({regY:132.4,rotation:7.2364,x:83.75,y:132.45},14,cjs.Ease.quadOut).wait(1));

	// 3
	this.instance_5 = new lib.Symbol21();
	this.instance_5.parent = this;
	this.instance_5.setTransform(92.75,209.65,1,1,0,0,0,100,205);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:204.9,rotation:7.7063,x:51.6,y:206.55},15,cjs.Ease.quadIn).to({regY:205,rotation:49.1791,x:15.85,y:192.05},15,cjs.Ease.quadOut).to({rotation:61.6928,x:80.6,y:209.65},15,cjs.Ease.quadIn).to({rotation:0,x:92.75},14,cjs.Ease.quadOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109,-47.3,440.7,410.8);


(lib.Symbol29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol11();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol29, new cjs.Rectangle(0,0,300,250), null);


(lib.Symbol28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol8();
	this.instance.parent = this;
	this.instance.setTransform(122.2,61.4,0.8437,1,-0.5674,0,0,122.1,61.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:122,scaleX:1,rotation:-5.284},29).to({regX:122.1,scaleX:0.8437,rotation:-0.5674},30).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.1,-34.1,257,282.90000000000003);


(lib.Symbol24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol7();
	this.instance.parent = this;
	this.instance.setTransform(107.8,72.3,1,1,0.0498,0,0,107.8,72.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:107.7,scaleX:1.2139,rotation:3.5019,x:109.35,y:72.35},29).to({regX:107.8,scaleX:1,rotation:0.0498,x:107.8,y:72.3},30).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.9,-32.2,267.2,287);


(lib.Symbol23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol14();
	this.instance.parent = this;
	this.instance.setTransform(111.75,47.8,1,1,-0.2745,0,0,111,49.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-0.3471,x:111.95,y:47.25},7).to({x:111.15,y:49.65},16,cjs.Ease.quadInOut).to({x:111.95,y:47.25},14,cjs.Ease.quadInOut).to({x:111.15,y:49.65},14,cjs.Ease.quadInOut).wait(1).to({regX:97,regY:117.5,rotation:-0.3456,x:97.6,y:117.55},0).wait(1).to({rotation:-0.3417,y:117.45},0).wait(1).to({rotation:-0.3351,x:97.7,y:117.3},0).wait(1).to({rotation:-0.3256,y:117.05},0).wait(1).to({rotation:-0.3133,x:97.8,y:116.8},0).wait(1).to({rotation:-0.2994,x:97.9,y:116.5},0).wait(1).to({rotation:-0.286,x:98,y:116.1},0).wait(1).to({regX:111,regY:49.6,rotation:-0.2745,x:111.75,y:47.8},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-2.9,196.2,238.6);


(lib.Symbol38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol36();
	this.instance.parent = this;
	this.instance.setTransform(69.4,69.35,0.3612,0.3612,0,0,0,64.8,64.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:69.35,y:69.3,alpha:1},19).wait(2).to({alpha:0},10).wait(9));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,138.8,138.9);


(lib.Symbol26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// arm1
	this.instance = new lib.Symbol24();
	this.instance.parent = this;
	this.instance.setTransform(97.2,117.95,1,1,0,0,0,97,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(217));

	// body
	this.instance_1 = new lib.Symbol12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(71.4,105.3,1,1,0,0,0,71.4,105.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(217));

	// head
	this.instance_2 = new lib.Symbol23("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(97.2,117.95,1,1,0,0,0,97,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(217));

	// arm2
	this.instance_3 = new lib.Symbol28();
	this.instance_3.parent = this;
	this.instance_3.setTransform(97.2,117.95,1,1,0,0,0,97,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(217));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2.4,196.3,239);


(lib.Symbol27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Symbol26("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(125.4,138.3,1,1,0.2037,0,0,72.4,130.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(248));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(52.6,6,196.3,238.4);


(lib.warrv2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Body
	this.instance = new lib.Symbol27("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(8.9,2.65,1,1,0,0,0,1.9,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:1},0).wait(1).to({y:128.6,startPosition:2},0).wait(1).to({y:128.75,startPosition:3},0).wait(1).to({y:128.95,startPosition:4},0).wait(1).to({y:129.15,startPosition:5},0).wait(1).to({y:129.3,startPosition:6},0).wait(1).to({y:129.5,startPosition:7},0).wait(1).to({y:129.7,startPosition:8},0).wait(1).to({y:129.9,startPosition:9},0).wait(1).to({y:130.1,startPosition:10},0).wait(1).to({y:130.3,startPosition:11},0).wait(1).to({y:130.5,startPosition:12},0).wait(1).to({y:130.7,startPosition:13},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:14},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:15},0).wait(1).to({y:130.6,startPosition:16},0).wait(1).to({y:130.4,startPosition:17},0).wait(1).to({y:130.25,startPosition:18},0).wait(1).to({y:130.1,startPosition:19},0).wait(1).to({y:129.9,startPosition:20},0).wait(1).to({y:129.75,startPosition:21},0).wait(1).to({y:129.55,startPosition:22},0).wait(1).to({y:129.35,startPosition:23},0).wait(1).to({y:129.2,startPosition:24},0).wait(1).to({y:129,startPosition:25},0).wait(1).to({y:128.8,startPosition:26},0).wait(1).to({y:128.6,startPosition:27},0).wait(1).to({y:128.4,startPosition:28},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:29},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:30},0).wait(1).to({y:128.55,startPosition:31},0).wait(1).to({y:128.75,startPosition:32},0).wait(1).to({y:128.9,startPosition:33},0).wait(1).to({y:129.1,startPosition:34},0).wait(1).to({y:129.25,startPosition:35},0).wait(1).to({y:129.45,startPosition:36},0).wait(1).to({y:129.6,startPosition:37},0).wait(1).to({y:129.8,startPosition:38},0).wait(1).to({y:130,startPosition:39},0).wait(1).to({y:130.15,startPosition:40},0).wait(1).to({y:130.35,startPosition:41},0).wait(1).to({y:130.55,startPosition:42},0).wait(1).to({y:130.75,startPosition:43},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:44},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:45},0).wait(1).to({y:130.6,startPosition:46},0).wait(1).to({y:130.4,startPosition:47},0).wait(1).to({y:130.25,startPosition:48},0).wait(1).to({y:130.05,startPosition:49},0).wait(1).to({y:129.9,startPosition:50},0).wait(1).to({y:129.7,startPosition:51},0).wait(1).to({y:129.55,startPosition:52},0).wait(1).to({y:129.35,startPosition:53},0).wait(1).to({y:129.15,startPosition:54},0).wait(1).to({y:129,startPosition:55},0).wait(1).to({y:128.8,startPosition:56},0).wait(1).to({y:128.6,startPosition:57},0).wait(1).to({y:128.4,startPosition:58},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:59},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:60},0).wait(1).to({y:128.55,startPosition:61},0).wait(1).to({y:128.7,startPosition:62},0).wait(1).to({y:128.85,startPosition:63},0).wait(1).to({y:129.05,startPosition:64},0).wait(1).to({y:129.2,startPosition:65},0).wait(1).to({y:129.35,startPosition:66},0).wait(1).to({y:129.55,startPosition:67},0).wait(1).to({y:129.7,startPosition:68},0).wait(1).to({y:129.85,startPosition:69},0).wait(1).to({y:130.05,startPosition:70},0).wait(1).to({y:130.2,startPosition:71},0).wait(1).to({y:130.4,startPosition:72},0).wait(1).to({y:130.55,startPosition:73},0).wait(1).to({y:130.75,startPosition:74},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:75},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:76},0).wait(1).to({y:130.55,startPosition:77},0).wait(1).to({y:130.35,startPosition:78},0).wait(1).to({y:130.2,startPosition:79},0).wait(1).to({y:130,startPosition:80},0).wait(1).to({y:129.8,startPosition:81},0).wait(1).to({y:129.6,startPosition:82},0).wait(1).to({y:129.4,startPosition:83},0).wait(1).to({y:129.2,startPosition:84},0).wait(1).to({y:129,startPosition:85},0).wait(1).to({y:128.85,startPosition:86},0).wait(1).to({y:128.65,startPosition:87},0).wait(1).to({y:128.45,startPosition:88},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:89},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:90},0).wait(1).to({y:128.55,startPosition:91},0).wait(1).to({y:128.7,startPosition:92},0).wait(1).to({y:128.85,startPosition:93},0).wait(1).to({y:129.05,startPosition:94},0).wait(1).to({y:129.2,startPosition:95},0).wait(1).to({y:129.35,startPosition:96},0).wait(1).to({y:129.55,startPosition:97},0).wait(1).to({y:129.7,startPosition:98},0).wait(1).to({y:129.9,startPosition:99},0).wait(1).to({y:130.05,startPosition:100},0).wait(1).to({y:130.2,startPosition:101},0).wait(1).to({y:130.4,startPosition:102},0).wait(1).to({y:130.55,startPosition:103},0).wait(1).to({y:130.75,startPosition:104},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:105},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:106},0).wait(1).to({y:130.55,startPosition:107},0).wait(1).to({y:130.35,startPosition:108},0).wait(1).to({y:130.2,startPosition:109},0).wait(1).to({y:130,startPosition:110},0).wait(1).to({y:129.8,startPosition:111},0).wait(1).to({y:129.6,startPosition:112},0).wait(1).to({y:129.4,startPosition:113},0).wait(1).to({y:129.2,startPosition:114},0).wait(1).to({y:129,startPosition:115},0).wait(1).to({y:128.8,startPosition:116},0).wait(1).to({y:128.6,startPosition:117},0).wait(1).to({y:128.45,startPosition:118},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:119},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:120},0).wait(1).to({y:128.55,startPosition:121},0).wait(1).to({y:128.7,startPosition:122},0).wait(1).to({y:128.9,startPosition:123},0).wait(1).to({y:129.05,startPosition:124},0).wait(1).to({y:129.2,startPosition:125},0).wait(1).to({y:129.4,startPosition:126},0).wait(1).to({y:129.55,startPosition:127},0).wait(1).to({y:129.7,startPosition:128},0).wait(1).to({y:129.9,startPosition:129},0).wait(1).to({y:130.05,startPosition:130},0).wait(1).to({y:130.25,startPosition:131},0).wait(1).to({y:130.4,startPosition:132},0).wait(1).to({y:130.55,startPosition:133},0).wait(1).to({y:130.75,startPosition:134},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:135},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:136},0).wait(1).to({y:130.55,startPosition:137},0).wait(1).to({y:130.35,startPosition:138},0).wait(1).to({y:130.15,startPosition:139},0).wait(1).to({y:130,startPosition:140},0).wait(1).to({y:129.8,startPosition:141},0).wait(1).to({y:129.6,startPosition:142},0).wait(1).to({y:129.4,startPosition:143},0).wait(1).to({y:129.2,startPosition:144},0).wait(1).to({y:129,startPosition:145},0).wait(1).to({y:128.8,startPosition:146},0).wait(1).to({y:128.6,startPosition:147},0).wait(1).to({y:128.4,startPosition:148},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:149},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:128.4,startPosition:150},0).wait(1).to({y:128.55,startPosition:151},0).wait(1).to({y:128.75,startPosition:152},0).wait(1).to({y:128.95,startPosition:153},0).wait(1).to({y:129.1,startPosition:154},0).wait(1).to({y:129.3,startPosition:155},0).wait(1).to({y:129.45,startPosition:156},0).wait(1).to({y:129.65,startPosition:157},0).wait(1).to({y:129.8,startPosition:158},0).wait(1).to({y:130,startPosition:159},0).wait(1).to({y:130.2,startPosition:160},0).wait(1).to({y:130.35,startPosition:161},0).wait(1).to({y:130.55,startPosition:162},0).wait(1).to({y:130.75,startPosition:163},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:5.35,startPosition:164},0).wait(1).to({regX:146.8,regY:127.5,x:153.8,y:130.75,startPosition:165},0).wait(1).to({y:130.6,startPosition:166},0).wait(1).to({y:130.4,startPosition:167},0).wait(1).to({y:130.2,startPosition:168},0).wait(1).to({y:130.05,startPosition:169},0).wait(1).to({y:129.85,startPosition:170},0).wait(1).to({y:129.7,startPosition:171},0).wait(1).to({y:129.5,startPosition:172},0).wait(1).to({y:129.35,startPosition:173},0).wait(1).to({y:129.15,startPosition:174},0).wait(1).to({y:128.95,startPosition:175},0).wait(1).to({y:128.8,startPosition:176},0).wait(1).to({y:128.6,startPosition:177},0).wait(1).to({y:128.4,startPosition:178},0).wait(1).to({regX:1.9,regY:1.9,x:8.9,y:2.65,startPosition:179},0).wait(1));

	// Leg22.png
	this.instance_1 = new lib.Symbol33("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,125.5,1,1,0,0,0,97,117.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:1},0).wait(1).to({y:166.45,startPosition:2},0).wait(1).to({y:166.6,startPosition:3},0).wait(1).to({y:166.8,startPosition:4},0).wait(1).to({y:167,startPosition:5},0).wait(1).to({y:167.15,startPosition:6},0).wait(1).to({y:167.35,startPosition:7},0).wait(1).to({y:167.55,startPosition:8},0).wait(1).to({y:167.75,startPosition:9},0).wait(1).to({y:167.95,startPosition:10},0).wait(1).to({y:168.15,startPosition:11},0).wait(1).to({y:168.35,startPosition:12},0).wait(1).to({y:168.55,startPosition:13},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:14},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:15},0).wait(1).to({y:168.45,startPosition:16},0).wait(1).to({y:168.25,startPosition:17},0).wait(1).to({y:168.1,startPosition:18},0).wait(1).to({y:167.95,startPosition:19},0).wait(1).to({y:167.75,startPosition:20},0).wait(1).to({y:167.6,startPosition:21},0).wait(1).to({y:167.4,startPosition:22},0).wait(1).to({y:167.2,startPosition:23},0).wait(1).to({y:167.05,startPosition:24},0).wait(1).to({y:166.85,startPosition:25},0).wait(1).to({y:166.65,startPosition:26},0).wait(1).to({y:166.45,startPosition:27},0).wait(1).to({y:166.25,startPosition:28},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:29},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:30},0).wait(1).to({y:166.4,startPosition:31},0).wait(1).to({y:166.6,startPosition:32},0).wait(1).to({y:166.75,startPosition:33},0).wait(1).to({y:166.95,startPosition:34},0).wait(1).to({y:167.1,startPosition:35},0).wait(1).to({y:167.3,startPosition:36},0).wait(1).to({y:167.45,startPosition:37},0).wait(1).to({y:167.65,startPosition:38},0).wait(1).to({y:167.85,startPosition:39},0).wait(1).to({y:168,startPosition:40},0).wait(1).to({y:168.2,startPosition:41},0).wait(1).to({y:168.4,startPosition:42},0).wait(1).to({y:168.6,startPosition:43},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:44},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:45},0).wait(1).to({y:168.45,startPosition:46},0).wait(1).to({y:168.25,startPosition:47},0).wait(1).to({y:168.1,startPosition:48},0).wait(1).to({y:167.9,startPosition:49},0).wait(1).to({y:167.75,startPosition:50},0).wait(1).to({y:167.55,startPosition:51},0).wait(1).to({y:167.4,startPosition:52},0).wait(1).to({y:167.2,startPosition:53},0).wait(1).to({y:167,startPosition:54},0).wait(1).to({y:166.85,startPosition:55},0).wait(1).to({y:166.65,startPosition:56},0).wait(1).to({y:166.45,startPosition:57},0).wait(1).to({y:166.25,startPosition:58},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:59},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:0},0).wait(1).to({y:166.4,startPosition:1},0).wait(1).to({y:166.55,startPosition:2},0).wait(1).to({y:166.7,startPosition:3},0).wait(1).to({y:166.9,startPosition:4},0).wait(1).to({y:167.05,startPosition:5},0).wait(1).to({y:167.2,startPosition:6},0).wait(1).to({y:167.4,startPosition:7},0).wait(1).to({y:167.55,startPosition:8},0).wait(1).to({y:167.7,startPosition:9},0).wait(1).to({y:167.9,startPosition:10},0).wait(1).to({y:168.05,startPosition:11},0).wait(1).to({y:168.25,startPosition:12},0).wait(1).to({y:168.4,startPosition:13},0).wait(1).to({y:168.6,startPosition:14},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:15},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:16},0).wait(1).to({y:168.4,startPosition:17},0).wait(1).to({y:168.2,startPosition:18},0).wait(1).to({y:168.05,startPosition:19},0).wait(1).to({y:167.85,startPosition:20},0).wait(1).to({y:167.65,startPosition:21},0).wait(1).to({y:167.45,startPosition:22},0).wait(1).to({y:167.25,startPosition:23},0).wait(1).to({y:167.05,startPosition:24},0).wait(1).to({y:166.85,startPosition:25},0).wait(1).to({y:166.7,startPosition:26},0).wait(1).to({y:166.5,startPosition:27},0).wait(1).to({y:166.3,startPosition:28},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:29},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:30},0).wait(1).to({y:166.4,startPosition:31},0).wait(1).to({y:166.55,startPosition:32},0).wait(1).to({y:166.7,startPosition:33},0).wait(1).to({y:166.9,startPosition:34},0).wait(1).to({y:167.05,startPosition:35},0).wait(1).to({y:167.2,startPosition:36},0).wait(1).to({y:167.4,startPosition:37},0).wait(1).to({y:167.55,startPosition:38},0).wait(1).to({y:167.75,startPosition:39},0).wait(1).to({y:167.9,startPosition:40},0).wait(1).to({y:168.05,startPosition:41},0).wait(1).to({y:168.25,startPosition:42},0).wait(1).to({y:168.4,startPosition:43},0).wait(1).to({y:168.6,startPosition:44},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:45},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:46},0).wait(1).to({y:168.4,startPosition:47},0).wait(1).to({y:168.2,startPosition:48},0).wait(1).to({y:168.05,startPosition:49},0).wait(1).to({y:167.85,startPosition:50},0).wait(1).to({y:167.65,startPosition:51},0).wait(1).to({y:167.45,startPosition:52},0).wait(1).to({y:167.25,startPosition:53},0).wait(1).to({y:167.05,startPosition:54},0).wait(1).to({y:166.85,startPosition:55},0).wait(1).to({y:166.65,startPosition:56},0).wait(1).to({y:166.45,startPosition:57},0).wait(1).to({y:166.3,startPosition:58},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:59},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:0},0).wait(1).to({y:166.4,startPosition:1},0).wait(1).to({y:166.55,startPosition:2},0).wait(1).to({y:166.75,startPosition:3},0).wait(1).to({y:166.9,startPosition:4},0).wait(1).to({y:167.05,startPosition:5},0).wait(1).to({y:167.25,startPosition:6},0).wait(1).to({y:167.4,startPosition:7},0).wait(1).to({y:167.55,startPosition:8},0).wait(1).to({y:167.75,startPosition:9},0).wait(1).to({y:167.9,startPosition:10},0).wait(1).to({y:168.1,startPosition:11},0).wait(1).to({y:168.25,startPosition:12},0).wait(1).to({y:168.4,startPosition:13},0).wait(1).to({y:168.6,startPosition:14},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:15},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:16},0).wait(1).to({y:168.4,startPosition:17},0).wait(1).to({y:168.2,startPosition:18},0).wait(1).to({y:168,startPosition:19},0).wait(1).to({y:167.85,startPosition:20},0).wait(1).to({y:167.65,startPosition:21},0).wait(1).to({y:167.45,startPosition:22},0).wait(1).to({y:167.25,startPosition:23},0).wait(1).to({y:167.05,startPosition:24},0).wait(1).to({y:166.85,startPosition:25},0).wait(1).to({y:166.65,startPosition:26},0).wait(1).to({y:166.45,startPosition:27},0).wait(1).to({y:166.25,startPosition:28},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:29},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:166.25,startPosition:30},0).wait(1).to({y:166.4,startPosition:31},0).wait(1).to({y:166.6,startPosition:32},0).wait(1).to({y:166.8,startPosition:33},0).wait(1).to({y:166.95,startPosition:34},0).wait(1).to({y:167.15,startPosition:35},0).wait(1).to({y:167.3,startPosition:36},0).wait(1).to({y:167.5,startPosition:37},0).wait(1).to({y:167.65,startPosition:38},0).wait(1).to({y:167.85,startPosition:39},0).wait(1).to({y:168.05,startPosition:40},0).wait(1).to({y:168.2,startPosition:41},0).wait(1).to({y:168.4,startPosition:42},0).wait(1).to({y:168.6,startPosition:43},0).wait(1).to({regX:97,regY:117.5,x:150,y:128.2,startPosition:44},0).wait(1).to({regX:119.3,regY:158.1,x:172.3,y:168.6,startPosition:45},0).wait(1).to({y:168.45,startPosition:46},0).wait(1).to({y:168.25,startPosition:47},0).wait(1).to({y:168.05,startPosition:48},0).wait(1).to({y:167.9,startPosition:49},0).wait(1).to({y:167.7,startPosition:50},0).wait(1).to({y:167.55,startPosition:51},0).wait(1).to({y:167.35,startPosition:52},0).wait(1).to({y:167.2,startPosition:53},0).wait(1).to({y:167,startPosition:54},0).wait(1).to({y:166.8,startPosition:55},0).wait(1).to({y:166.65,startPosition:56},0).wait(1).to({y:166.45,startPosition:57},0).wait(1).to({y:166.25,startPosition:58},0).wait(1).to({regX:97,regY:117.5,x:150,y:125.5,startPosition:59},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-38.9,440.7,413.09999999999997);


// stage content:
(lib._181208adtr300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_205 = function() {
		if(!this.loops_played) this.loops_played = 1;
		if(this.loops_played >= 3) {
			this.stop();
			}
		else {
		this.loops_played++;
		};
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(205).call(this.frame_205).wait(105));

	// Layer_37
	this.instance = new lib.Symbol39();
	this.instance.parent = this;
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(290).to({_off:false},0).to({alpha:1},19).wait(1));

	// m (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_287 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_288 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_289 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_290 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_291 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_292 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_293 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_294 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_295 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_296 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_297 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_298 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_299 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_300 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_301 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_graphics_302 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(287).to({graphics:mask_graphics_287,x:450,y:125}).wait(1).to({graphics:mask_graphics_288,x:449.65,y:125}).wait(1).to({graphics:mask_graphics_289,x:447.15,y:125}).wait(1).to({graphics:mask_graphics_290,x:440.4,y:125}).wait(1).to({graphics:mask_graphics_291,x:427.25,y:125}).wait(1).to({graphics:mask_graphics_292,x:405.55,y:125}).wait(1).to({graphics:mask_graphics_293,x:373.2,y:125}).wait(1).to({graphics:mask_graphics_294,x:328.05,y:125}).wait(1).to({graphics:mask_graphics_295,x:271.95,y:125}).wait(1).to({graphics:mask_graphics_296,x:226.8,y:125}).wait(1).to({graphics:mask_graphics_297,x:194.45,y:125}).wait(1).to({graphics:mask_graphics_298,x:172.75,y:125}).wait(1).to({graphics:mask_graphics_299,x:159.6,y:125}).wait(1).to({graphics:mask_graphics_300,x:152.85,y:125}).wait(1).to({graphics:mask_graphics_301,x:150.35,y:125}).wait(1).to({graphics:mask_graphics_302,x:150,y:125}).wait(8));

	// bg_rust.jpg copy
	this.instance_1 = new lib.Symbol29();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(287).to({_off:false},0).wait(23));

	// m (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_279 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_280 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_281 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_282 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_283 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_284 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_285 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_286 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_287 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_288 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_289 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_290 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_291 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_292 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_293 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	var mask_1_graphics_294 = new cjs.Graphics().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(279).to({graphics:mask_1_graphics_279,x:450,y:125}).wait(1).to({graphics:mask_1_graphics_280,x:449.65,y:125}).wait(1).to({graphics:mask_1_graphics_281,x:447.15,y:125}).wait(1).to({graphics:mask_1_graphics_282,x:440.4,y:125}).wait(1).to({graphics:mask_1_graphics_283,x:427.25,y:125}).wait(1).to({graphics:mask_1_graphics_284,x:405.55,y:125}).wait(1).to({graphics:mask_1_graphics_285,x:373.2,y:125}).wait(1).to({graphics:mask_1_graphics_286,x:328.05,y:125}).wait(1).to({graphics:mask_1_graphics_287,x:272,y:125}).wait(1).to({graphics:mask_1_graphics_288,x:226.85,y:125}).wait(1).to({graphics:mask_1_graphics_289,x:194.5,y:125}).wait(1).to({graphics:mask_1_graphics_290,x:172.8,y:125}).wait(1).to({graphics:mask_1_graphics_291,x:159.65,y:125}).wait(1).to({graphics:mask_1_graphics_292,x:152.9,y:125}).wait(1).to({graphics:mask_1_graphics_293,x:150.4,y:125}).wait(1).to({graphics:mask_1_graphics_294,x:150.05,y:125}).wait(16));

	// bg_norust.jpg copy
	this.instance_2 = new lib.Symbol10();
	this.instance_2.parent = this;
	this.instance_2.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(279).to({_off:false},0).wait(31));

	// m (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_214 = new cjs.Graphics().p("AAwSnQgwAAAAgwIAAjNQAAgwAwAAIVBAAQAwAAgBAwIAADNQABAwgwAAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(214).to({graphics:mask_2_graphics_214,x:144.05,y:119.075}).wait(80).to({graphics:null,x:0,y:0}).wait(16));

	// light
	this.instance_3 = new lib.Symbol35();
	this.instance_3.parent = this;
	this.instance_3.setTransform(104.25,223.45,1.2069,1.1873,0,0,0,34.6,37.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(214).to({_off:false},0).to({x:329.85},10).wait(1).to({x:104.25},0).to({x:329.85},10).wait(17).to({x:104.25},0).to({x:329.85},10).wait(1).to({x:104.25},0).to({x:329.85},10).to({_off:true},21).wait(16));

	// cta.png
	this.instance_4 = new lib.Symbol13();
	this.instance_4.parent = this;
	this.instance_4.setTransform(214.7,273,1,1,0,0,0,214.7,223);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(186).to({_off:false},0).to({y:223,alpha:1},16,cjs.Ease.backOut).to({_off:true},92).wait(16));

	// t11.png
	this.instance_5 = new lib.Symbol4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(250,125,1,1,0,0,0,150,125);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(160).to({_off:false},0).to({x:150,alpha:1},16,cjs.Ease.backOut).to({_off:true},118).wait(16));

	// t12.png
	this.instance_6 = new lib.Symbol5();
	this.instance_6.parent = this;
	this.instance_6.setTransform(250,125,1,1,0,0,0,150,125);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(162).to({_off:false},0).to({x:150,alpha:1},16,cjs.Ease.backOut).to({_off:true},116).wait(16));

	// t13.png
	this.instance_7 = new lib.Symbol6();
	this.instance_7.parent = this;
	this.instance_7.setTransform(250,125,1,1,0,0,0,150,125);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(164).to({_off:false},0).to({x:150,alpha:1},16,cjs.Ease.backOut).to({_off:true},114).wait(16));

	// m (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_181 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_182 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_183 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_184 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_185 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_186 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_187 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_188 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_189 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_190 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_191 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_192 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_193 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_194 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_195 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_196 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");
	var mask_3_graphics_197 = new cjs.Graphics().p("AqWD9IAAn5IUtAAIAAH5g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(181).to({graphics:mask_3_graphics_181,x:84.025,y:111.975}).wait(1).to({graphics:mask_3_graphics_182,x:98.975,y:111.975}).wait(1).to({graphics:mask_3_graphics_183,x:112.075,y:111.975}).wait(1).to({graphics:mask_3_graphics_184,x:123.425,y:111.975}).wait(1).to({graphics:mask_3_graphics_185,x:133.175,y:111.975}).wait(1).to({graphics:mask_3_graphics_186,x:141.425,y:111.975}).wait(1).to({graphics:mask_3_graphics_187,x:148.275,y:111.975}).wait(1).to({graphics:mask_3_graphics_188,x:153.875,y:111.975}).wait(1).to({graphics:mask_3_graphics_189,x:158.425,y:111.975}).wait(1).to({graphics:mask_3_graphics_190,x:161.925,y:111.975}).wait(1).to({graphics:mask_3_graphics_191,x:164.525,y:111.975}).wait(1).to({graphics:mask_3_graphics_192,x:166.425,y:111.975}).wait(1).to({graphics:mask_3_graphics_193,x:167.675,y:111.975}).wait(1).to({graphics:mask_3_graphics_194,x:168.475,y:111.975}).wait(1).to({graphics:mask_3_graphics_195,x:168.875,y:111.975}).wait(1).to({graphics:mask_3_graphics_196,x:169.025,y:111.975}).wait(1).to({graphics:mask_3_graphics_197,x:169.025,y:111.975}).wait(113));

	// label.png
	this.instance_8 = new lib.Symbol15();
	this.instance_8.parent = this;
	this.instance_8.setTransform(221.6,115.3,1,1,0,0,0,171.6,115.3);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(181).to({_off:false},0).to({x:171.6},16,cjs.Ease.cubicOut).to({_off:true},97).wait(16));

	// p2.png
	this.instance_9 = new lib.Symbol1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(150.5,172.85,0.1207,0.1207,0,0,0,150.3,157.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(154).to({_off:false},0).to({regX:150.5,scaleX:1,scaleY:1,y:157.8,alpha:1},16,cjs.Ease.backOut).to({_off:true},124).wait(16));

	// m (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_153 = new cjs.Graphics().p("AoTIiIAAxDIQnAAIAARDg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(153).to({graphics:mask_4_graphics_153,x:201.475,y:156.125}).wait(6).to({graphics:null,x:0,y:0}).wait(151));

	// p3.png
	this.instance_10 = new lib.Symbol2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(90,125,1,1,0,0,0,150,125);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(153).to({_off:false},0).wait(4).to({x:150,alpha:1},16,cjs.Ease.quartOut).to({_off:true},121).wait(16));

	// m (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_155 = new cjs.Graphics().p("Ar1NYIAA6vIXrAAIAAavg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(155).to({graphics:mask_5_graphics_155,x:78.25,y:154.675}).wait(7).to({graphics:null,x:0,y:0}).wait(148));

	// p1.png
	this.instance_11 = new lib.Symbol32();
	this.instance_11.parent = this;
	this.instance_11.setTransform(205,125,1,1,0,0,0,150,125);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(155).to({_off:false},0).wait(4).to({x:150,alpha:1},16,cjs.Ease.quartOut).to({_off:true},119).wait(16));

	// legal.png
	this.instance_12 = new lib.Symbol31();
	this.instance_12.parent = this;
	this.instance_12.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(176).to({_off:false},0).to({alpha:1},16).to({_off:true},102).wait(16));

	// bg.png
	this.instance_13 = new lib.Symbol9();
	this.instance_13.parent = this;
	this.instance_13.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(143).to({_off:false},0).to({alpha:1},12).to({_off:true},139).wait(16));

	// logo
	this.instance_14 = new lib.Symbol52("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(45).to({startPosition:0},0).to({alpha:0},4).to({_off:true},2).wait(259));

	// m (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_0 = new cjs.Graphics().p("A6yTiMAAAgnDMA1lAAAMAAAAnDg");
	var mask_6_graphics_1 = new cjs.Graphics().p("A6yTiMAAAgnDMA1lAAAMAAAAnDg");
	var mask_6_graphics_2 = new cjs.Graphics().p("A6yTiMAAAgnDMA1lAAAMAAAAnDg");
	var mask_6_graphics_3 = new cjs.Graphics().p("A6yTiMAAAgnDMA1lAAAMAAAAnDg");
	var mask_6_graphics_4 = new cjs.Graphics().p("A6yTiMAAAgnDMA1kAAAMAAAAnDg");
	var mask_6_graphics_5 = new cjs.Graphics().p("A6xTiMAAAgnDMA1kAAAMAAAAnDg");
	var mask_6_graphics_6 = new cjs.Graphics().p("A6xTiMAAAgnDMA1jAAAMAAAAnDg");
	var mask_6_graphics_7 = new cjs.Graphics().p("A6xTiMAAAgnDMA1jAAAMAAAAnDg");
	var mask_6_graphics_8 = new cjs.Graphics().p("A6wTiMAAAgnDMA1hAAAMAAAAnDg");
	var mask_6_graphics_9 = new cjs.Graphics().p("A6vTiMAAAgnDMA1fAAAMAAAAnDg");
	var mask_6_graphics_10 = new cjs.Graphics().p("A6uTiMAAAgnDMA1dAAAMAAAAnDg");
	var mask_6_graphics_11 = new cjs.Graphics().p("A6sTiMAAAgnDMA1ZAAAMAAAAnDg");
	var mask_6_graphics_12 = new cjs.Graphics().p("A6qTiMAAAgnDMA1VAAAMAAAAnDg");
	var mask_6_graphics_13 = new cjs.Graphics().p("A6nTiMAAAgnDMA1QAAAMAAAAnDg");
	var mask_6_graphics_14 = new cjs.Graphics().p("A6lTiMAAAgnDMA1LAAAMAAAAnDg");
	var mask_6_graphics_15 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_16 = new cjs.Graphics().p("A6iTiMAAAgnDMA1FAAAMAAAAnDg");
	var mask_6_graphics_17 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_18 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_19 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_20 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_21 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_22 = new cjs.Graphics().p("A6iTiMAAAgnDMA1GAAAMAAAAnDg");
	var mask_6_graphics_23 = new cjs.Graphics().p("A6jTiMAAAgnDMA1GAAAMAAAAnDg");
	var mask_6_graphics_24 = new cjs.Graphics().p("A6jTiMAAAgnDMA1HAAAMAAAAnDg");
	var mask_6_graphics_25 = new cjs.Graphics().p("A6cTiMAAAgnDMA05AAAMAAAAnDg");
	var mask_6_graphics_26 = new cjs.Graphics().p("A6STiMAAAgnDMA0lAAAMAAAAnDg");
	var mask_6_graphics_27 = new cjs.Graphics().p("A6STiMAAAgnDMA0lAAAMAAAAnDg");
	var mask_6_graphics_28 = new cjs.Graphics().p("A6RTiMAAAgnDMA0jAAAMAAAAnDg");
	var mask_6_graphics_29 = new cjs.Graphics().p("A6QTiMAAAgnDMA0hAAAMAAAAnDg");
	var mask_6_graphics_30 = new cjs.Graphics().p("A6PTiMAAAgnDMA0fAAAMAAAAnDg");
	var mask_6_graphics_31 = new cjs.Graphics().p("A6NTiMAAAgnDMA0bAAAMAAAAnDg");
	var mask_6_graphics_32 = new cjs.Graphics().p("A6MTiMAAAgnDMA0ZAAAMAAAAnDg");
	var mask_6_graphics_33 = new cjs.Graphics().p("A6KTiMAAAgnDMA0VAAAMAAAAnDg");
	var mask_6_graphics_34 = new cjs.Graphics().p("A6ITiMAAAgnDMA0RAAAMAAAAnDg");
	var mask_6_graphics_35 = new cjs.Graphics().p("A6GTiMAAAgnDMA0NAAAMAAAAnDg");
	var mask_6_graphics_36 = new cjs.Graphics().p("A6ETiMAAAgnDMA0IAAAMAAAAnDg");
	var mask_6_graphics_37 = new cjs.Graphics().p("A6BTiMAAAgnDMA0DAAAMAAAAnDg");
	var mask_6_graphics_38 = new cjs.Graphics().p("A5+TiMAAAgnDMAz9AAAMAAAAnDg");
	var mask_6_graphics_39 = new cjs.Graphics().p("A58TiMAAAgnDMAz5AAAMAAAAnDg");
	var mask_6_graphics_40 = new cjs.Graphics().p("A56TiMAAAgnDMAz1AAAMAAAAnDg");
	var mask_6_graphics_41 = new cjs.Graphics().p("A55TiMAAAgnDMAzzAAAMAAAAnDg");
	var mask_6_graphics_42 = new cjs.Graphics().p("A55TiMAAAgnDMAzzAAAMAAAAnDg");
	var mask_6_graphics_43 = new cjs.Graphics().p("A54TiMAAAgnDMAzxAAAMAAAAnDg");
	var mask_6_graphics_44 = new cjs.Graphics().p("A54TiMAAAgnDMAzwAAAMAAAAnDg");
	var mask_6_graphics_45 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_46 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_47 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_48 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_49 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_50 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_51 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_52 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_53 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_54 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_55 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_56 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_57 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_58 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_59 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_60 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_61 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_62 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_63 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_64 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_65 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_66 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_67 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_68 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_69 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_70 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_71 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");
	var mask_6_graphics_72 = new cjs.Graphics().p("A53TiMAAAgnDMAzvAAAMAAAAnDg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:mask_6_graphics_0,x:169.95,y:125}).wait(1).to({graphics:mask_6_graphics_1,x:174.025,y:125}).wait(1).to({graphics:mask_6_graphics_2,x:178.525,y:125}).wait(1).to({graphics:mask_6_graphics_3,x:183.425,y:125}).wait(1).to({graphics:mask_6_graphics_4,x:188.75,y:125}).wait(1).to({graphics:mask_6_graphics_5,x:194.55,y:125}).wait(1).to({graphics:mask_6_graphics_6,x:200.825,y:125}).wait(1).to({graphics:mask_6_graphics_7,x:201.275,y:125}).wait(1).to({graphics:mask_6_graphics_8,x:201.825,y:125}).wait(1).to({graphics:mask_6_graphics_9,x:202.55,y:125}).wait(1).to({graphics:mask_6_graphics_10,x:204.85,y:125}).wait(1).to({graphics:mask_6_graphics_11,x:207.875,y:125}).wait(1).to({graphics:mask_6_graphics_12,x:209.65,y:125}).wait(1).to({graphics:mask_6_graphics_13,x:211.65,y:125}).wait(1).to({graphics:mask_6_graphics_14,x:215.5,y:125}).wait(1).to({graphics:mask_6_graphics_15,x:219.1,y:125}).wait(1).to({graphics:mask_6_graphics_16,x:224.45,y:125}).wait(1).to({graphics:mask_6_graphics_17,x:229.55,y:125}).wait(1).to({graphics:mask_6_graphics_18,x:235.75,y:125}).wait(1).to({graphics:mask_6_graphics_19,x:240.7,y:125}).wait(1).to({graphics:mask_6_graphics_20,x:247,y:125}).wait(1).to({graphics:mask_6_graphics_21,x:251.6,y:125}).wait(1).to({graphics:mask_6_graphics_22,x:259.85,y:125}).wait(1).to({graphics:mask_6_graphics_23,x:265.2,y:125}).wait(1).to({graphics:mask_6_graphics_24,x:268.15,y:125}).wait(1).to({graphics:mask_6_graphics_25,x:273.825,y:125}).wait(1).to({graphics:mask_6_graphics_26,x:282.725,y:125}).wait(1).to({graphics:mask_6_graphics_27,x:286.1,y:125}).wait(1).to({graphics:mask_6_graphics_28,x:290.375,y:125}).wait(1).to({graphics:mask_6_graphics_29,x:295.65,y:125}).wait(1).to({graphics:mask_6_graphics_30,x:298.55,y:125}).wait(1).to({graphics:mask_6_graphics_31,x:302.325,y:125}).wait(1).to({graphics:mask_6_graphics_32,x:303.225,y:125.15}).wait(1).to({graphics:mask_6_graphics_33,x:304.25,y:125.3}).wait(1).to({graphics:mask_6_graphics_34,x:305.325,y:125.45}).wait(1).to({graphics:mask_6_graphics_35,x:306.925,y:125.2}).wait(1).to({graphics:mask_6_graphics_36,x:308.45,y:125}).wait(1).to({graphics:mask_6_graphics_37,x:311.275,y:125}).wait(1).to({graphics:mask_6_graphics_38,x:313.9,y:125}).wait(1).to({graphics:mask_6_graphics_39,x:318.825,y:125}).wait(1).to({graphics:mask_6_graphics_40,x:322.55,y:125}).wait(1).to({graphics:mask_6_graphics_41,x:332.65,y:125}).wait(1).to({graphics:mask_6_graphics_42,x:340.55,y:125}).wait(1).to({graphics:mask_6_graphics_43,x:346.575,y:125}).wait(1).to({graphics:mask_6_graphics_44,x:356.65,y:125}).wait(1).to({graphics:mask_6_graphics_45,x:363.6,y:125}).wait(1).to({graphics:mask_6_graphics_46,x:367.85,y:125}).wait(1).to({graphics:mask_6_graphics_47,x:376.45,y:125}).wait(1).to({graphics:mask_6_graphics_48,x:385.85,y:125}).wait(1).to({graphics:mask_6_graphics_49,x:393.85,y:125}).wait(1).to({graphics:mask_6_graphics_50,x:402.5,y:125}).wait(1).to({graphics:mask_6_graphics_51,x:408.55,y:125}).wait(1).to({graphics:mask_6_graphics_52,x:415.1,y:125}).wait(1).to({graphics:mask_6_graphics_53,x:419.65,y:125}).wait(1).to({graphics:mask_6_graphics_54,x:424.55,y:125}).wait(1).to({graphics:mask_6_graphics_55,x:428.9,y:125}).wait(1).to({graphics:mask_6_graphics_56,x:433.55,y:125}).wait(1).to({graphics:mask_6_graphics_57,x:435.8,y:125}).wait(1).to({graphics:mask_6_graphics_58,x:438.15,y:125}).wait(1).to({graphics:mask_6_graphics_59,x:440.7,y:125}).wait(1).to({graphics:mask_6_graphics_60,x:443.3,y:125}).wait(1).to({graphics:mask_6_graphics_61,x:446.05,y:125}).wait(1).to({graphics:mask_6_graphics_62,x:448.95,y:125}).wait(1).to({graphics:mask_6_graphics_63,x:451.55,y:125}).wait(1).to({graphics:mask_6_graphics_64,x:454.25,y:125}).wait(1).to({graphics:mask_6_graphics_65,x:454.05,y:125}).wait(1).to({graphics:mask_6_graphics_66,x:453.8,y:125}).wait(1).to({graphics:mask_6_graphics_67,x:454,y:125}).wait(1).to({graphics:mask_6_graphics_68,x:454.25,y:125}).wait(1).to({graphics:mask_6_graphics_69,x:455.8,y:125}).wait(1).to({graphics:mask_6_graphics_70,x:457.4,y:125}).wait(1).to({graphics:mask_6_graphics_71,x:462.45,y:125}).wait(1).to({graphics:mask_6_graphics_72,x:467.75,y:125}).wait(238));

	// bg_rust.jpg
	this.instance_15 = new lib.Symbol29();
	this.instance_15.parent = this;
	this.instance_15.setTransform(150,125,1,1,0,0,0,150,125);

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({_off:true},73).wait(237));

	// Layer_6
	this.instance_16 = new lib.Symbol40("synched",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(274.7,144.5,1.2345,1.2345,0,0,0,20.5,85.5);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(110).to({_off:false},0).to({_off:true},52).wait(148));

	// Layer_3
	this.instance_17 = new lib.warrv2("synched",0);
	this.instance_17.parent = this;
	this.instance_17.setTransform(-174.75,41.1,1,1,0,0,0,58.2,29.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({x:-141.75,startPosition:1},6).to({x:-140.3,startPosition:2},1).to({x:-138.7,startPosition:4},2).to({x:-133.55,startPosition:6},2).to({x:-128.6,startPosition:8},2).to({x:-120.6,startPosition:10},2).to({x:-71.6,startPosition:19},9).to({x:-59.85,startPosition:21},2).to({x:-46.55,startPosition:24},3).to({x:-39.35,startPosition:26},2).to({x:-35.25,startPosition:28},3).to({x:-29.55,startPosition:30},2).to({x:-23.55,startPosition:32},2).to({x:-14.5,startPosition:34},2).to({x:30.25,startPosition:40},6).to({x:50.3,startPosition:42},2).to({x:67.3,startPosition:44},2).to({x:80.35,startPosition:46},2).to({x:89.3,startPosition:48},2).to({x:98.15,startPosition:50},2).to({x:117.75,startPosition:59},8).to({x:118.85,startPosition:61},2).to({x:118.5,startPosition:63},2).to({x:121.5,startPosition:65},2).to({x:167.35,startPosition:76},11).to({x:181.55,startPosition:78},2).to({x:194.75,startPosition:80},2).to({x:212.15,startPosition:83},3).to({x:221.15,startPosition:86},3).to({x:224.8,startPosition:88},2).to({x:225.75,startPosition:90},2).to({x:374.7,startPosition:121},31).to({_off:true},1).wait(183));

	// sparkles copy 2
	this.instance_18 = new lib.Symbol38();
	this.instance_18.parent = this;
	this.instance_18.setTransform(164.65,80.05,1,1,0,0,0,69.4,69.4);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(30).to({_off:false},0).to({_off:true},121).wait(159));

	// sparkles copy 3
	this.instance_19 = new lib.Symbol38();
	this.instance_19.parent = this;
	this.instance_19.setTransform(236.15,99.55,1,1,0,0,0,69.4,69.4);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(22).to({_off:false},0).to({_off:true},129).wait(159));

	// sparkles copy
	this.instance_20 = new lib.Symbol38();
	this.instance_20.parent = this;
	this.instance_20.setTransform(112.65,158.05,1,1,0,0,0,69.4,69.4);
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(14).to({_off:false},0).to({_off:true},137).wait(159));

	// sparkles
	this.instance_21 = new lib.Symbol38();
	this.instance_21.parent = this;
	this.instance_21.setTransform(67.15,28.05,1,1,0,0,0,69.4,69.4);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(5).to({_off:false},0).to({_off:true},146).wait(159));

	// bg_norust.jpg
	this.instance_22 = new lib.Symbol10();
	this.instance_22.parent = this;
	this.instance_22.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).to({_off:true},151).wait(159));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-98.7,-24.8,706.7,480.6);
// library properties:
lib.properties = {
	id: 'D989D54A625F9644B2784B6617044FF1',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"181208_adtr_300x250_atlas_P_.png", id:"181208_adtr_300x250_atlas_P_"},
		{src:"181208_adtr_300x250_atlas_NP_.jpg", id:"181208_adtr_300x250_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D989D54A625F9644B2784B6617044FF1'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;